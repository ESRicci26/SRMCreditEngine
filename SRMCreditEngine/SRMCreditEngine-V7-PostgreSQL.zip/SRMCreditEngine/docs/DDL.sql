-- ============================================================================
-- SRM Credit Engine - DDL (PostgreSQL) - V2
-- Este script documenta a estrutura gerada automaticamente pelo Hibernate
-- (spring.jpa.hibernate.ddl-auto=update) na primeira subida da aplicacao.
-- Pode tambem ser executado manualmente para inspecionar/recriar o schema.
--
-- Nota (V2): na V1 (SQLite), as foreign keys nao eram declaradas via ALTER
-- TABLE por limitacao do proprio SQLite (ver README, secao "Decisoes de
-- Design"). No PostgreSQL essa limitacao nao existe, entao as constraints de
-- chave estrangeira abaixo sao reais e enforced pelo banco.
-- ============================================================================

CREATE TABLE IF NOT EXISTS currency (
    id     BIGSERIAL PRIMARY KEY,
    code   VARCHAR(10) NOT NULL UNIQUE,
    name   VARCHAR(60) NOT NULL,
    symbol VARCHAR(5)  NOT NULL
);

CREATE TABLE IF NOT EXISTS receivable_type (
    id             BIGSERIAL PRIMARY KEY,
    code           VARCHAR(40) NOT NULL UNIQUE,
    description    VARCHAR(80) NOT NULL,
    monthly_spread NUMERIC(9,6) NOT NULL
);

CREATE TABLE IF NOT EXISTS base_rate (
    id           BIGSERIAL PRIMARY KEY,
    currency_id  BIGINT NOT NULL REFERENCES currency(id),
    monthly_rate NUMERIC(9,6) NOT NULL,
    effective_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS exchange_rate (
    id                 BIGSERIAL PRIMARY KEY,
    base_currency_id   BIGINT NOT NULL REFERENCES currency(id),
    target_currency_id BIGINT NOT NULL REFERENCES currency(id),
    rate               NUMERIC(19,8) NOT NULL,
    effective_at       TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS transaction_ledger (
    id                      BIGSERIAL PRIMARY KEY,
    assignor                VARCHAR(120) NOT NULL,
    receivable_type_id      BIGINT NOT NULL REFERENCES receivable_type(id),
    face_value              NUMERIC(19,4) NOT NULL,
    face_currency_id        BIGINT NOT NULL REFERENCES currency(id),
    due_date                DATE NOT NULL,
    term_months             NUMERIC(9,4) NOT NULL,
    base_rate_applied       NUMERIC(9,6) NOT NULL,
    spread_applied          NUMERIC(9,6) NOT NULL,
    present_value           NUMERIC(19,4) NOT NULL,
    settlement_currency_id  BIGINT NOT NULL REFERENCES currency(id),
    exchange_rate_applied   NUMERIC(19,8),
    settled_value           NUMERIC(19,4) NOT NULL,
    status                  VARCHAR(20) NOT NULL,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    version                 BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_transaction_due_date ON transaction_ledger (due_date);
CREATE INDEX IF NOT EXISTS idx_transaction_assignor ON transaction_ledger (assignor);
CREATE INDEX IF NOT EXISTS idx_transaction_status ON transaction_ledger (status);

-- ============================================================================
-- Seed inicial (executado automaticamente por SemeadorDados.java na primeira
-- inicializacao; reproduzido aqui apenas como referencia documental)
-- ============================================================================

-- INSERT INTO currency (code, name, symbol) VALUES ('BRL', 'Real Brasileiro', 'R$');
-- INSERT INTO currency (code, name, symbol) VALUES ('USD', 'Dolar Americano', 'US$');

-- INSERT INTO receivable_type (code, description, monthly_spread)
--   VALUES ('DUPLICATA_MERCANTIL', 'Duplicata Mercantil', 0.0150);
-- INSERT INTO receivable_type (code, description, monthly_spread)
--   VALUES ('CHEQUE_PRE_DATADO', 'Cheque Pre-datado', 0.0250);
