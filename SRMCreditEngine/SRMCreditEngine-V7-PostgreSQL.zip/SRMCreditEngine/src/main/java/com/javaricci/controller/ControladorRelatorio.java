package com.javaricci.controller;

import com.javaricci.dto.response.LinhaExtratoDto;
import com.javaricci.repository.RepositorioRelatorioExtrato;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

/**
 * Extrato de Liquidacao (relatorio analitico).
 *
 * <p>Conforme o requisito 6, este endpoint e propositalmente organizado em
 * apenas duas camadas (Controlador -&gt; Repositorio), sem passar pela
 * camada de servico de negocio, usando SQL nativo para desempenho em
 * grandes volumes.</p>
 */
@RestController
@RequestMapping("/api/reports")
@Tag(name = "Relatorios", description = "Consultas analiticas (Extrato de Liquidacao)")
public class ControladorRelatorio {

    private final RepositorioRelatorioExtrato repositorioRelatorioExtrato;

    public ControladorRelatorio(RepositorioRelatorioExtrato repositorioRelatorioExtrato) {
        this.repositorioRelatorioExtrato = repositorioRelatorioExtrato;
    }

    @GetMapping("/extrato")
    @Operation(summary = "Extrato de liquidacao filtravel por periodo, cedente e moeda")
    public ResponseEntity<Page<LinhaExtratoDto>> extrato(
            @RequestParam LocalDate inicio,
            @RequestParam LocalDate fim,
            @RequestParam(required = false) String cedente,
            @RequestParam(required = false) String moeda,
            @RequestParam(defaultValue = "0") int pagina,
            @RequestParam(defaultValue = "20") int tamanho) {

        int deslocamento = pagina * tamanho;
        List<LinhaExtratoDto> linhas = repositorioRelatorioExtrato.buscarExtrato(
                inicio, fim, cedente, moeda, tamanho, deslocamento);
        long total = repositorioRelatorioExtrato.contarExtrato(inicio, fim, cedente, moeda);

        Page<LinhaExtratoDto> resultado = new PageImpl<>(linhas, PageRequest.of(pagina, tamanho), total);
        return ResponseEntity.ok(resultado);
    }
}
