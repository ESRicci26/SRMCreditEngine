package com.javaricci.service;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TipoRecebivel;
import com.javaricci.domain.entity.Transacao;
import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.StatusTransacao;
import com.javaricci.dto.request.RequisicaoSimulacaoDto;
import com.javaricci.dto.response.RespostaSimulacaoPrecificacaoDto;
import com.javaricci.dto.response.RespostaTransacaoDto;
import com.javaricci.exception.ExcecaoNegocio;
import com.javaricci.exception.ExcecaoLiquidacaoConcorrente;
import com.javaricci.exception.ExcecaoRecursoNaoEncontrado;
import com.javaricci.repository.RepositorioTipoRecebivel;
import com.javaricci.repository.RepositorioTransacao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;

/**
 * Servico de aplicacao que persiste aquisicoes de recebiveis e as liquida,
 * respeitando a semantica ACID: toda transicao de estado acontece dentro de
 * uma unica fronteira transacional, e a liquidacao e protegida por
 * optimistic locking (ver {@link Transacao#getVersao()}) para que duas
 * requisicoes de liquidacao concorrentes sobre o mesmo registro nao possam
 * ambas ter sucesso.
 */
@Service
public class ServicoTransacao {

    private static final Logger log = LoggerFactory.getLogger(ServicoTransacao.class);

    private final RepositorioTransacao repositorioTransacao;
    private final RepositorioTipoRecebivel repositorioTipoRecebivel;
    private final ServicoMoeda servicoMoeda;
    private final ServicoPrecificacao servicoPrecificacao;

    public ServicoTransacao(RepositorioTransacao repositorioTransacao,
                             RepositorioTipoRecebivel repositorioTipoRecebivel,
                             ServicoMoeda servicoMoeda,
                             ServicoPrecificacao servicoPrecificacao) {
        this.repositorioTransacao = repositorioTransacao;
        this.repositorioTipoRecebivel = repositorioTipoRecebivel;
        this.servicoMoeda = servicoMoeda;
        this.servicoPrecificacao = servicoPrecificacao;
    }

    /** Precifica e persiste uma nova aquisicao, com situacao PENDENTE. */
    @Transactional
    public RespostaTransacaoDto criar(RequisicaoSimulacaoDto requisicao) {
        RespostaSimulacaoPrecificacaoDto precificacao = servicoPrecificacao.simular(requisicao);

        TipoRecebivel tipoRecebivel = repositorioTipoRecebivel.findByCodigo(requisicao.getTipoRecebivel())
                .orElseThrow(() -> new ExcecaoNegocio(
                        "Tipo de recebivel nao cadastrado: " + requisicao.getTipoRecebivel()));
        Moeda moedaFace = servicoMoeda.buscarPorCodigo(requisicao.getMoedaFace());
        Moeda moedaLiquidacao = servicoMoeda.buscarPorCodigo(requisicao.getMoedaLiquidacao());

        Transacao transacao = Transacao.builder()
                .cedente(requisicao.getCedente())
                .tipoRecebivel(tipoRecebivel)
                .valorFace(requisicao.getValorFace())
                .moedaFace(moedaFace)
                .dataVencimento(requisicao.getDataVencimento())
                .prazoMeses(precificacao.getPrazoMeses())
                .taxaBaseAplicada(precificacao.getTaxaBaseAplicada())
                .spreadAplicado(precificacao.getSpreadAplicado())
                .valorPresente(precificacao.getValorPresenteMoedaFace())
                .moedaLiquidacao(moedaLiquidacao)
                .taxaCambioAplicada(precificacao.getTaxaCambioAplicada())
                .valorLiquidado(precificacao.getValorLiquidado())
                .situacao(StatusTransacao.PENDENTE)
                .build();

        Transacao salva = repositorioTransacao.save(transacao);
        log.info("Transacao #{} criada para cedente '{}' - valor presente {} {}",
                salva.getId(), salva.getCedente(), salva.getValorPresente(), salva.getMoedaFace().getCodigo());
        return paraDto(salva);
    }

    public RespostaTransacaoDto buscarPorId(Long id) {
        return paraDto(buscarOuFalhar(id));
    }

    public Page<RespostaTransacaoDto> buscar(String cedente, CodigoMoeda codigoMoeda, LocalDate inicio,
                                              LocalDate fim, StatusTransacao situacao, Pageable paginacao) {
        Specification<Transacao> especificacao = construirEspecificacao(cedente, codigoMoeda, inicio, fim, situacao);
        return repositorioTransacao.findAll(especificacao, paginacao).map(this::paraDto);
    }

    /**
     * Liquida uma transacao pendente. Seguro para concorrencia: usa o
     * optimistic lock do JPA ({@code @Version}), traduzindo uma atualizacao
     * perdida em uma {@link ExcecaoLiquidacaoConcorrente} de dominio (mapeada
     * para HTTP 409 pelo manipulador global de excecoes) em vez de uma
     * sobrescrita silenciosa.
     */
    @Transactional
    public RespostaTransacaoDto liquidar(Long id, Long versaoEsperada) {
        Transacao transacao = buscarOuFalhar(id);

        if (versaoEsperada != null && !versaoEsperada.equals(transacao.getVersao())) {
            throw new ExcecaoLiquidacaoConcorrente(
                    "A transacao #" + id + " ja foi modificada por outra operacao (versao divergente).");
        }
        if (transacao.getSituacao() != StatusTransacao.PENDENTE) {
            throw new ExcecaoNegocio(
                    "Somente transacoes com situacao PENDENTE podem ser liquidadas. Situacao atual: "
                            + transacao.getSituacao());
        }

        transacao.setSituacao(StatusTransacao.LIQUIDADA);
        try {
            Transacao liquidada = repositorioTransacao.saveAndFlush(transacao);
            log.info("Transacao #{} liquidada com sucesso.", id);
            return paraDto(liquidada);
        } catch (OptimisticLockingFailureException excecao) {
            throw new ExcecaoLiquidacaoConcorrente(
                    "Conflito de concorrencia ao liquidar a transacao #" + id + ".");
        }
    }

    private Transacao buscarOuFalhar(Long id) {
        return repositorioTransacao.findById(id)
                .orElseThrow(() -> new ExcecaoRecursoNaoEncontrado("Transacao nao encontrada: " + id));
    }

    private Specification<Transacao> construirEspecificacao(String cedente, CodigoMoeda codigoMoeda, LocalDate inicio,
                                                              LocalDate fim, StatusTransacao situacao) {
        return (raiz, consulta, cb) -> {
            var predicados = cb.conjunction();
            if (StringUtils.hasText(cedente)) {
                predicados = cb.and(predicados,
                        cb.like(cb.lower(raiz.get("cedente")), "%" + cedente.toLowerCase() + "%"));
            }
            if (codigoMoeda != null) {
                // cb.literal(...) forca um tipo explicito no parametro (em vez de depender da
                // inferencia de tipo do path aninhado via @ManyToOne), evitando um problema
                // conhecido do Criteria API legado do Hibernate 5.6 onde o tipo do enum pode se
                // perder ao reutilizar o mesmo valor em dois cb.equal(...) dentro de um cb.or(...).
                var moedaLiteral = cb.literal(codigoMoeda);
                predicados = cb.and(predicados, cb.or(
                        cb.equal(raiz.get("moedaFace").get("codigo"), moedaLiteral),
                        cb.equal(raiz.get("moedaLiquidacao").get("codigo"), moedaLiteral)));
            }
            if (inicio != null) {
                predicados = cb.and(predicados, cb.greaterThanOrEqualTo(raiz.get("dataVencimento"), inicio));
            }
            if (fim != null) {
                predicados = cb.and(predicados, cb.lessThanOrEqualTo(raiz.get("dataVencimento"), fim));
            }
            if (situacao != null) {
                predicados = cb.and(predicados, cb.equal(raiz.get("situacao"), situacao));
            }
            return predicados;
        };
    }

    private RespostaTransacaoDto paraDto(Transacao t) {
        return RespostaTransacaoDto.builder()
                .id(t.getId())
                .cedente(t.getCedente())
                .tipoRecebivel(t.getTipoRecebivel().getCodigo().name())
                .valorFace(t.getValorFace())
                .moedaFace(t.getMoedaFace().getCodigo().name())
                .dataVencimento(t.getDataVencimento())
                .prazoMeses(t.getPrazoMeses())
                .taxaBaseAplicada(t.getTaxaBaseAplicada())
                .spreadAplicado(t.getSpreadAplicado())
                .valorPresente(t.getValorPresente())
                .moedaLiquidacao(t.getMoedaLiquidacao().getCodigo().name())
                .taxaCambioAplicada(t.getTaxaCambioAplicada())
                .valorLiquidado(t.getValorLiquidado())
                .situacao(t.getSituacao().name())
                .versao(t.getVersao())
                .criadoEm(t.getCriadoEm())
                .atualizadoEm(t.getAtualizadoEm())
                .build();
    }
}
