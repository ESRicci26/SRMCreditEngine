package com.javaricci.config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Registra uma conversao global e tolerante a espacos em branco de
 * {@code String} para {@link LocalDate}, usada por todo {@code @RequestParam
 * LocalDate} da aplicacao (filtros de data em transacoes, extrato, etc).
 *
 * <p><b>Por que isso existe:</b> o formatador padrao do Spring/Java para
 * {@code LocalDate} (via {@code DateTimeFormatter.ISO_LOCAL_DATE}) rejeita
 * qualquer espaco em branco (inclusive tabs) antes ou depois do valor,
 * lancando {@code MethodArgumentTypeMismatchException}. Isso pode acontecer
 * com um simples "cole" de um campo de data vindo de outra fonte (planilha,
 * autocompletar do navegador, etc), que insere um caractere invisivel junto
 * com a data. Este conversor faz um {@code trim()} defensivo antes de tentar
 * o parse, e substitui o formatador padrao baseado em anotacao
 * {@code @DateTimeFormat} (que nao e tolerante a espacos) para todos os
 * parametros do tipo {@code LocalDate} da aplicacao - por isso os
 * controladores voltaram a usar {@code @RequestParam LocalDate} simples, sem
 * a anotacao {@code @DateTimeFormat}.</p>
 */
@Configuration
public class ConfiguracaoConversaoWeb implements WebMvcConfigurer {

    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new ConversorTextoParaLocalDate());
    }

    /** Converte texto (com espacos/tabs nas bordas ignorados) para {@link LocalDate} no formato ISO (yyyy-MM-dd). */
    static class ConversorTextoParaLocalDate implements Converter<String, LocalDate> {

        @Override
        @Nullable
        public LocalDate convert(String origem) {
            if (origem == null) {
                return null;
            }
            String textoTratado = origem.trim();
            if (textoTratado.isEmpty()) {
                return null;
            }
            return LocalDate.parse(textoTratado, DateTimeFormatter.ISO_LOCAL_DATE);
        }
    }
}
