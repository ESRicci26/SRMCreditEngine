package com.javaricci.controller;

import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.StatusTransacao;
import com.javaricci.dto.request.RequisicaoSimulacaoDto;
import com.javaricci.dto.response.RespostaTransacaoDto;
import com.javaricci.service.ServicoTransacao;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.LocalDate;

/** Aquisicao (cessao) e liquidacao de recebiveis. */
@RestController
@RequestMapping("/api/transactions")
@Tag(name = "Transacoes", description = "Aquisicao, consulta e liquidacao de recebiveis")
public class ControladorTransacao {

    private final ServicoTransacao servicoTransacao;

    public ControladorTransacao(ServicoTransacao servicoTransacao) {
        this.servicoTransacao = servicoTransacao;
    }

    @PostMapping
    @Operation(summary = "Precifica e persiste a aquisicao de um recebivel (situacao PENDENTE)")
    public ResponseEntity<RespostaTransacaoDto> criar(@Valid @RequestBody RequisicaoSimulacaoDto requisicao) {
        RespostaTransacaoDto criada = servicoTransacao.criar(requisicao);
        return ResponseEntity.status(HttpStatus.CREATED).body(criada);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Consulta uma transacao por id")
    public ResponseEntity<RespostaTransacaoDto> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(servicoTransacao.buscarPorId(id));
    }

    @GetMapping
    @Operation(summary = "Lista transacoes com filtros dinamicos e paginacao server-side")
    public ResponseEntity<Page<RespostaTransacaoDto>> buscar(
            @RequestParam(required = false) String cedente,
            @RequestParam(required = false) CodigoMoeda moeda,
            @RequestParam(required = false) @Parameter(description = "yyyy-MM-dd") LocalDate inicio,
            @RequestParam(required = false) @Parameter(description = "yyyy-MM-dd") LocalDate fim,
            @RequestParam(required = false) StatusTransacao situacao,
            @PageableDefault(size = 20, sort = "criadoEm") Pageable paginacao) {
        return ResponseEntity.ok(servicoTransacao.buscar(cedente, moeda, inicio, fim, situacao, paginacao));
    }

    @PostMapping("/{id}/settle")
    @Operation(summary = "Liquida uma transacao pendente (protegido por optimistic locking)")
    public ResponseEntity<RespostaTransacaoDto> liquidar(
            @PathVariable Long id,
            @RequestParam(required = false) Long versao) {
        return ResponseEntity.ok(servicoTransacao.liquidar(id, versao));
    }
}
