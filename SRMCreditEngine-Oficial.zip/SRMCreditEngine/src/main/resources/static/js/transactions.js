(function () {
  document.querySelectorAll('.btn-liquidar').forEach(function (botao) {
    botao.addEventListener('click', async function () {
      const id = botao.getAttribute('data-id');
      const versao = botao.getAttribute('data-versao');
      botao.disabled = true;
      try {
        const resposta = await fetch('/api/transactions/' + id + '/settle?versao=' + versao, {
          method: 'POST'
        });
        if (!resposta.ok) {
          const erro = await resposta.json();
          alert(erro.mensagem || 'Nao foi possivel liquidar a transacao.');
          botao.disabled = false;
          return;
        }
        window.location.reload();
      } catch (e) {
        alert('Falha de comunicacao com a API.');
        botao.disabled = false;
      }
    });
  });
})();
