(function () {
  const formulario = document.getElementById('formPrecificacao');
  const caixaAlerta = document.getElementById('caixaAlerta');
  let temporizador = null;

  function lerPayload() {
    return {
      cedente: document.getElementById('cedente').value,
      tipoRecebivel: document.getElementById('tipoRecebivel').value,
      valorFace: parseFloat(document.getElementById('valorFace').value || '0'),
      dataVencimento: document.getElementById('dataVencimento').value,
      moedaFace: document.getElementById('moedaFace').value,
      moedaLiquidacao: document.getElementById('moedaLiquidacao').value
    };
  }

  function mostrarErro(mensagem) {
    caixaAlerta.textContent = mensagem;
    caixaAlerta.classList.remove('d-none');
  }

  function esconderErro() {
    caixaAlerta.classList.add('d-none');
  }

  function renderizarResultado(dados) {
    document.getElementById('outPrazo').textContent = dados.prazoMeses;
    document.getElementById('outTaxaBase').textContent = (dados.taxaBaseAplicada * 100).toFixed(4) + '%';
    document.getElementById('outSpread').textContent = (dados.spreadAplicado * 100).toFixed(4) + '%';
    document.getElementById('outValorPresente').textContent = dados.valorPresenteMoedaFace + ' ' + dados.moedaFace;
    document.getElementById('outTaxaCambio').textContent = dados.taxaCambioAplicada ? dados.taxaCambioAplicada : 'N/A (mesma moeda)';
    document.getElementById('outValorLiquidado').textContent = dados.valorLiquidado + ' ' + dados.moedaLiquidacao;
  }

  async function simular() {
    const payload = lerPayload();
    if (!payload.cedente || !payload.valorFace || !payload.dataVencimento) {
      return;
    }
    try {
      const resposta = await fetch('/api/pricing/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!resposta.ok) {
        const erro = await resposta.json();
        mostrarErro(erro.mensagem || 'Erro ao simular precificacao.');
        return;
      }
      esconderErro();
      renderizarResultado(await resposta.json());
    } catch (e) {
      mostrarErro('Falha de comunicacao com a API.');
    }
  }

  formulario.addEventListener('input', function () {
    clearTimeout(temporizador);
    temporizador = setTimeout(simular, 350);
  });

  formulario.addEventListener('submit', async function (evento) {
    evento.preventDefault();
    const payload = lerPayload();
    try {
      const resposta = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!resposta.ok) {
        const erro = await resposta.json();
        mostrarErro(erro.mensagem || 'Erro ao registrar transacao.');
        return;
      }
      window.location.href = '/transacoes';
    } catch (e) {
      mostrarErro('Falha de comunicacao com a API.');
    }
  });
})();
