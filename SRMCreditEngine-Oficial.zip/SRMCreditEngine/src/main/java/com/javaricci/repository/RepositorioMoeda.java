package com.javaricci.repository;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.enums.CodigoMoeda;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RepositorioMoeda extends JpaRepository<Moeda, Long> {
    Optional<Moeda> findByCodigo(CodigoMoeda codigo);
}
