package com.javaricci.repository;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TaxaBase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RepositorioTaxaBase extends JpaRepository<TaxaBase, Long> {
    Optional<TaxaBase> findFirstByMoedaOrderByVigenteEmDesc(Moeda moeda);
}
