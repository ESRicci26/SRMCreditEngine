package com.javaricci.repository;

import com.javaricci.domain.entity.TipoRecebivel;
import com.javaricci.domain.enums.CodigoTipoRecebivel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RepositorioTipoRecebivel extends JpaRepository<TipoRecebivel, Long> {
    Optional<TipoRecebivel> findByCodigo(CodigoTipoRecebivel codigo);
}
