package com.javaricci.repository;

import com.javaricci.domain.entity.Transacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RepositorioTransacao extends JpaRepository<Transacao, Long>,
        JpaSpecificationExecutor<Transacao> {
}
