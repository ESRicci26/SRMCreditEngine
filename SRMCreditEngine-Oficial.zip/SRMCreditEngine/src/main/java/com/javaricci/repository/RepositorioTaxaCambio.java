package com.javaricci.repository;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TaxaCambio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RepositorioTaxaCambio extends JpaRepository<TaxaCambio, Long> {

    Optional<TaxaCambio> findFirstByMoedaBaseAndMoedaAlvoOrderByVigenteEmDesc(
            Moeda moedaBase, Moeda moedaAlvo);

    List<TaxaCambio> findAllByOrderByVigenteEmDesc();
}
