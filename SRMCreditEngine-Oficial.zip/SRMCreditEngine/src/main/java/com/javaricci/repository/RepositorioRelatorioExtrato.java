package com.javaricci.repository;

import com.javaricci.dto.response.LinhaExtratoDto;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Consultas analiticas do "Extrato de Liquidacao".
 *
 * <p>Conforme o requisito 6, este componente e propositalmente organizado em
 * apenas duas camadas (Controlador -&gt; Repositorio), sem passar pela camada
 * de servico de negocio, usando SQL nativo via {@link NamedParameterJdbcTemplate}
 * em vez do JPA/ORM para filtragem otimizada em grandes volumes.</p>
 *
 * <p>Nota de escopo: os nomes de tabelas/colunas abaixo permanecem no schema
 * fisico original (em ingles, ja documentado em {@code docs/DDL.sql}); apenas
 * os identificadores Java (classe, metodos, variaveis) foram traduzidos.</p>
 */
@Repository
public class RepositorioRelatorioExtrato {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public RepositorioRelatorioExtrato(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<LinhaExtratoDto> buscarExtrato(LocalDate inicio, LocalDate fim, String cedente,
                                                String codigoMoeda, int tamanho, int deslocamento) {
        StringBuilder sql = new StringBuilder(
                "SELECT t.id, t.assignor, rt.code AS receivable_type, t.face_value, "
                        + "fc.code AS face_currency, sc.code AS settlement_currency, "
                        + "t.due_date, t.present_value, t.settled_value, t.status, t.created_at "
                        + "FROM transaction_ledger t "
                        + "JOIN receivable_type rt ON rt.id = t.receivable_type_id "
                        + "JOIN currency fc ON fc.id = t.face_currency_id "
                        + "JOIN currency sc ON sc.id = t.settlement_currency_id "
                        + "WHERE t.due_date BETWEEN :inicio AND :fim ");

        MapSqlParameterSource parametros = new MapSqlParameterSource()
                .addValue("inicio", inicio)
                .addValue("fim", fim)
                .addValue("tamanho", tamanho)
                .addValue("deslocamento", deslocamento);

        if (cedente != null && !cedente.isBlank()) {
            sql.append("AND LOWER(t.assignor) LIKE LOWER(:cedente) ");
            parametros.addValue("cedente", "%" + cedente + "%");
        }
        if (codigoMoeda != null && !codigoMoeda.isBlank()) {
            sql.append("AND (fc.code = :codigoMoeda OR sc.code = :codigoMoeda) ");
            parametros.addValue("codigoMoeda", codigoMoeda);
        }

        sql.append("ORDER BY t.due_date DESC LIMIT :tamanho OFFSET :deslocamento");

        return jdbcTemplate.query(sql.toString(), parametros, (rs, numeroLinha) -> LinhaExtratoDto.builder()
                .id(rs.getLong("id"))
                .cedente(rs.getString("assignor"))
                .tipoRecebivel(rs.getString("receivable_type"))
                .valorFace(rs.getBigDecimal("face_value"))
                .moedaFace(rs.getString("face_currency"))
                .moedaLiquidacao(rs.getString("settlement_currency"))
                .dataVencimento(rs.getDate("due_date").toLocalDate())
                .valorPresente(rs.getBigDecimal("present_value"))
                .valorLiquidado(rs.getBigDecimal("settled_value"))
                .situacao(rs.getString("status"))
                .build());
    }

    public long contarExtrato(LocalDate inicio, LocalDate fim, String cedente, String codigoMoeda) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM transaction_ledger t "
                        + "JOIN currency fc ON fc.id = t.face_currency_id "
                        + "JOIN currency sc ON sc.id = t.settlement_currency_id "
                        + "WHERE t.due_date BETWEEN :inicio AND :fim ");

        MapSqlParameterSource parametros = new MapSqlParameterSource()
                .addValue("inicio", inicio)
                .addValue("fim", fim);

        if (cedente != null && !cedente.isBlank()) {
            sql.append("AND LOWER(t.assignor) LIKE LOWER(:cedente) ");
            parametros.addValue("cedente", "%" + cedente + "%");
        }
        if (codigoMoeda != null && !codigoMoeda.isBlank()) {
            sql.append("AND (fc.code = :codigoMoeda OR sc.code = :codigoMoeda) ");
            parametros.addValue("codigoMoeda", codigoMoeda);
        }

        Long total = jdbcTemplate.queryForObject(sql.toString(), parametros, Long.class);
        return total == null ? 0L : total;
    }
}
