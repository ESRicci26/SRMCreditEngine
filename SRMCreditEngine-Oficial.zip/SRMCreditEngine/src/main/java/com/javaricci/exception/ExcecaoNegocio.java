package com.javaricci.exception;

/** Lancada para violacoes de regras de negocio/dominio (estado invalido, entrada invalida a nivel de dominio, etc). */
public class ExcecaoNegocio extends RuntimeException {

    public ExcecaoNegocio(String mensagem) {
        super(mensagem);
    }

    public ExcecaoNegocio(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
