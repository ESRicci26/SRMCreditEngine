package com.javaricci.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.List;

/** Payload padrao de erro retornado pela API para qualquer falha. */
@Getter
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RespostaErro {
    private LocalDateTime dataHora;
    private int codigoStatus;
    private String erro;
    private String mensagem;
    private String caminho;
    private List<String> detalhes;
}
