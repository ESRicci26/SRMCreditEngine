package com.javaricci.exception;

/** Lancada quando uma entidade solicitada nao existe. */
public class ExcecaoRecursoNaoEncontrado extends RuntimeException {

    public ExcecaoRecursoNaoEncontrado(String mensagem) {
        super(mensagem);
    }
}
