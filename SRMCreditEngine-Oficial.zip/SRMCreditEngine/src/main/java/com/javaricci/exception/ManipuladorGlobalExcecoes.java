package com.javaricci.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Tratamento de excecoes centralizado e resiliente: toda falha e traduzida
 * em uma {@link RespostaErro} estruturada, em vez de vazar stack traces ou
 * interromper o fluxo de requisicao abruptamente.
 */
@RestControllerAdvice
public class ManipuladorGlobalExcecoes {

    private static final Logger log = LoggerFactory.getLogger(ManipuladorGlobalExcecoes.class);

    @ExceptionHandler(ExcecaoRecursoNaoEncontrado.class)
    public ResponseEntity<RespostaErro> tratarNaoEncontrado(ExcecaoRecursoNaoEncontrado excecao,
                                                             WebRequest requisicao) {
        return construir(HttpStatus.NOT_FOUND, excecao.getMessage(), requisicao, null);
    }

    @ExceptionHandler(ExcecaoNegocio.class)
    public ResponseEntity<RespostaErro> tratarNegocio(ExcecaoNegocio excecao, WebRequest requisicao) {
        return construir(HttpStatus.UNPROCESSABLE_ENTITY, excecao.getMessage(), requisicao, null);
    }

    @ExceptionHandler({ExcecaoLiquidacaoConcorrente.class, OptimisticLockingFailureException.class})
    public ResponseEntity<RespostaErro> tratarConflito(RuntimeException excecao, WebRequest requisicao) {
        log.warn("Conflito de concorrencia detectado: {}", excecao.getMessage());
        return construir(HttpStatus.CONFLICT,
                "A transacao foi alterada por outra operacao concorrente. Recarregue e tente novamente.",
                requisicao, null);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<RespostaErro> tratarValidacao(MethodArgumentNotValidException excecao,
                                                         WebRequest requisicao) {
        List<String> detalhes = excecao.getBindingResult().getFieldErrors().stream()
                .map(erroCampo -> erroCampo.getField() + ": " + erroCampo.getDefaultMessage())
                .collect(Collectors.toList());
        return construir(HttpStatus.BAD_REQUEST, "Erro de validacao nos dados enviados.", requisicao, detalhes);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<RespostaErro> tratarArgumentoInvalido(IllegalArgumentException excecao,
                                                                 WebRequest requisicao) {
        return construir(HttpStatus.BAD_REQUEST, excecao.getMessage(), requisicao, null);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<RespostaErro> tratarGenerico(Exception excecao, WebRequest requisicao) {
        log.error("Erro inesperado nao tratado", excecao);
        return construir(HttpStatus.INTERNAL_SERVER_ERROR,
                "Ocorreu um erro inesperado. A equipe tecnica foi notificada.", requisicao, null);
    }

    private ResponseEntity<RespostaErro> construir(HttpStatus status, String mensagem, WebRequest requisicao,
                                                     List<String> detalhes) {
        RespostaErro corpo = RespostaErro.builder()
                .dataHora(LocalDateTime.now())
                .codigoStatus(status.value())
                .erro(status.getReasonPhrase())
                .mensagem(mensagem)
                .caminho(requisicao.getDescription(false).replace("uri=", ""))
                .detalhes(detalhes)
                .build();
        return ResponseEntity.status(status).body(corpo);
    }
}
