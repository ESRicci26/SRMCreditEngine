package com.javaricci.exception;

/**
 * Lancada quando duas tentativas de liquidacao concorrem sobre a mesma
 * transacao e a verificacao de versao do optimistic locking falha.
 */
public class ExcecaoLiquidacaoConcorrente extends RuntimeException {

    public ExcecaoLiquidacaoConcorrente(String mensagem) {
        super(mensagem);
    }
}
