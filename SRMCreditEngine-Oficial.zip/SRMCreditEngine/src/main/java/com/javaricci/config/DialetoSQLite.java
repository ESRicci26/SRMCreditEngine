package com.javaricci.config;

import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.identity.IdentityColumnSupport;
import org.hibernate.dialect.identity.IdentityColumnSupportImpl;

import java.sql.Types;

/**
 * Dialect customizado do Hibernate para SQLite.
 *
 * <p><b>Por que isso existe:</b> {@code hibernate-community-dialects} (que traz
 * {@code org.hibernate.community.dialect.SQLiteDialect} pronto) so e publicado
 * para Hibernate ORM 6+ (groupId {@code org.hibernate.orm}). O Spring Boot
 * 2.7.x roda sobre Hibernate 5.6.x, que nao tem dialect oficial nenhum para
 * SQLite. Em vez de depender de um artefato de terceiros nao mantido/nao
 * oficial, este projeto define seu proprio dialect minimo - a mesma
 * abordagem comumente documentada para integracoes SQLite + Hibernate 5.x -
 * construido apenas sobre a API estavel de {@link Dialect} ja presente no
 * {@code hibernate-core}, sem exigir nenhuma dependencia extra.</p>
 *
 * <p>O escopo e deliberadamente limitado ao que o schema desta aplicacao
 * precisa: mapeamento basico de tipos de coluna e colunas identity
 * {@code INTEGER PRIMARY KEY} (o autoincremento nativo por rowid do SQLite).
 * A paginacao recorre a estrategia padrao em memoria do Hibernate (ver nota
 * sobre {@code getLimitHandler()} abaixo). O suporte muito limitado do
 * SQLite a {@code ALTER TABLE} faz com que a evolucao de schema alem do
 * {@code CREATE TABLE} inicial seja intencionalmente nao suportada aqui.</p>
 *
 * <p><b>Nota:</b> os nomes dos metodos abaixo (ex: {@code hasAlterTable},
 * {@code getForUpdateString}) sao contratos de sobrescrita da API do
 * Hibernate ({@link Dialect}) e por isso permanecem em ingles - traduzi-los
 * quebraria o override.</p>
 */
public class DialetoSQLite extends Dialect {

    public DialetoSQLite() {
        super();
        registerColumnType(Types.BIT, "integer");
        registerColumnType(Types.TINYINT, "tinyint");
        registerColumnType(Types.SMALLINT, "smallint");
        registerColumnType(Types.INTEGER, "integer");
        registerColumnType(Types.BIGINT, "bigint");
        registerColumnType(Types.FLOAT, "float");
        registerColumnType(Types.REAL, "real");
        registerColumnType(Types.DOUBLE, "double");
        registerColumnType(Types.NUMERIC, "numeric($p,$s)");
        registerColumnType(Types.DECIMAL, "decimal($p,$s)");
        registerColumnType(Types.CHAR, "char($l)");
        registerColumnType(Types.VARCHAR, "varchar($l)");
        registerColumnType(Types.LONGVARCHAR, "longvarchar");
        registerColumnType(Types.DATE, "date");
        registerColumnType(Types.TIME, "time");
        registerColumnType(Types.TIMESTAMP, "timestamp");
        registerColumnType(Types.BINARY, "blob");
        registerColumnType(Types.VARBINARY, "blob");
        registerColumnType(Types.LONGVARBINARY, "blob");
        registerColumnType(Types.BLOB, "blob");
        registerColumnType(Types.CLOB, "clob");
        registerColumnType(Types.BOOLEAN, "integer");
    }

    @Override
    public IdentityColumnSupport getIdentityColumnSupport() {
        return new IdentityColumnSupportImpl() {
            @Override
            public boolean supportsIdentityColumns() {
                return true;
            }

            @Override
            public boolean hasDataTypeInIdentityColumn() {
                return false;
            }

            @Override
            public String getIdentityColumnString(int tipo) throws MappingException {
                return "integer";
            }

            @Override
            public String getIdentitySelectString(String tabela, String coluna, int tipo) throws MappingException {
                return "select last_insert_rowid()";
            }
        };
    }

    @Override
    public boolean hasAlterTable() {
        // O suporte do SQLite a ALTER TABLE e limitado demais (sem ADD/DROP
        // CONSTRAINT) para confiar nele em atualizacoes de schema; esta
        // aplicacao so precisa de CREATE TABLE na primeira subida.
        return false;
    }

    @Override
    public boolean dropConstraints() {
        return false;
    }

    @Override
    public boolean supportsIfExistsBeforeTableName() {
        return true;
    }

    @Override
    public boolean supportsCascadeDelete() {
        return false;
    }

    @Override
    public boolean supportsCurrentTimestampSelection() {
        return true;
    }

    @Override
    public String getCurrentTimestampSelectString() {
        return "select current_timestamp";
    }

    @Override
    public boolean isCurrentTimestampSelectStringCallable() {
        return false;
    }

    // NOTA: getLimitHandler() foi deixado propositalmente no padrao do
    // Dialect (NoopLimitHandler), o que faz o Hibernate aplicar a paginacao
    // em memoria via pos-processamento do ResultSet. O SQLite suporta
    // "LIMIT n OFFSET m" a nivel de SQL, mas sem uma forma de validar por
    // compilacao a assinatura exata da SPI de paginacao neste ambiente,
    // optou-se pelo padrao mais seguro. Para os volumes de dados deste
    // desafio isso nao tem impacto pratico de desempenho; um handler nativo
    // de LIMIT/OFFSET pode ser adicionado depois se necessario.

    @Override
    public String getForUpdateString() {
        return "";
    }

    @Override
    public boolean supportsOuterJoinForUpdate() {
        return false;
    }
}
