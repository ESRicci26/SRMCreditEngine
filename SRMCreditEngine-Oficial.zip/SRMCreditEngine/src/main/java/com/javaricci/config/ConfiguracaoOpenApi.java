package com.javaricci.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Metadados do OpenAPI/Swagger para a documentacao publica da API. */
@Configuration
public class ConfiguracaoOpenApi {

    @Bean
    public OpenAPI configurarOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("SRM Credit Engine API")
                        .description("Plataforma de cessao de credito multimoedas (FIDC) - "
                                + "precificacao e liquidacao de recebiveis.")
                        .version("v1.0.0")
                        .contact(new Contact().name("SRM Asset - Mesa de Operacoes"))
                        .license(new License().name("Proprietary")));
    }
}
