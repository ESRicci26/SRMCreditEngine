package com.javaricci.config;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * Anexa um id de correlacao ao contexto de log (MDC) de cada requisicao, para
 * que logs estruturados possam ser rastreados de ponta a ponta em uma unica
 * operacao - uma peca leve e sem dependencias extras para observabilidade.
 */
@Component
public class FiltroCorrelacaoRequisicao extends OncePerRequestFilter {

    public static final String CABECALHO_ID_CORRELACAO = "X-Correlation-Id";
    public static final String CHAVE_MDC = "correlationId";

    @Override
    protected void doFilterInternal(HttpServletRequest requisicao, HttpServletResponse resposta, FilterChain cadeia)
            throws ServletException, IOException {
        String idCorrelacao = requisicao.getHeader(CABECALHO_ID_CORRELACAO);
        if (idCorrelacao == null || idCorrelacao.isBlank()) {
            idCorrelacao = UUID.randomUUID().toString();
        }
        try {
            MDC.put(CHAVE_MDC, idCorrelacao);
            resposta.setHeader(CABECALHO_ID_CORRELACAO, idCorrelacao);
            cadeia.doFilter(requisicao, resposta);
        } finally {
            MDC.remove(CHAVE_MDC);
        }
    }
}
