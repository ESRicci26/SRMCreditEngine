package com.javaricci.config;

import com.javaricci.domain.entity.TaxaBase;
import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TaxaCambio;
import com.javaricci.domain.entity.TipoRecebivel;
import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.CodigoTipoRecebivel;
import com.javaricci.repository.RepositorioTaxaBase;
import com.javaricci.repository.RepositorioMoeda;
import com.javaricci.repository.RepositorioTaxaCambio;
import com.javaricci.repository.RepositorioTipoRecebivel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Semeia dados de referencia (moedas, produtos de recebivel, taxas base e uma
 * taxa de cambio inicial) na primeira inicializacao, para que a API/UI ja
 * fiquem utilizaveis. Idempotente: nao faz nada se ja houver dados.
 */
@Component
public class SemeadorDados implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(SemeadorDados.class);

    private final RepositorioMoeda repositorioMoeda;
    private final RepositorioTipoRecebivel repositorioTipoRecebivel;
    private final RepositorioTaxaBase repositorioTaxaBase;
    private final RepositorioTaxaCambio repositorioTaxaCambio;

    public SemeadorDados(RepositorioMoeda repositorioMoeda,
                          RepositorioTipoRecebivel repositorioTipoRecebivel,
                          RepositorioTaxaBase repositorioTaxaBase,
                          RepositorioTaxaCambio repositorioTaxaCambio) {
        this.repositorioMoeda = repositorioMoeda;
        this.repositorioTipoRecebivel = repositorioTipoRecebivel;
        this.repositorioTaxaBase = repositorioTaxaBase;
        this.repositorioTaxaCambio = repositorioTaxaCambio;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (repositorioMoeda.count() > 0) {
            log.info("Dados de referencia ja existentes - seeding ignorado.");
            return;
        }
        log.info("Realizando seed inicial de dados de referencia (moedas, produtos, taxas)...");

        Moeda brl = repositorioMoeda.save(Moeda.builder()
                .codigo(CodigoMoeda.BRL).nome("Real Brasileiro").simbolo("R$").build());
        Moeda usd = repositorioMoeda.save(Moeda.builder()
                .codigo(CodigoMoeda.USD).nome("Dolar Americano").simbolo("US$").build());

        repositorioTipoRecebivel.save(TipoRecebivel.builder()
                .codigo(CodigoTipoRecebivel.DUPLICATA_MERCANTIL)
                .descricao("Duplicata Mercantil")
                .spreadMensal(new BigDecimal("0.0150"))
                .build());
        repositorioTipoRecebivel.save(TipoRecebivel.builder()
                .codigo(CodigoTipoRecebivel.CHEQUE_PRE_DATADO)
                .descricao("Cheque Pre-datado")
                .spreadMensal(new BigDecimal("0.0250"))
                .build());

        LocalDateTime agora = LocalDateTime.now();

        repositorioTaxaBase.save(TaxaBase.builder()
                .moeda(brl).taxaMensal(new BigDecimal("0.0090")).vigenteEm(agora).build());
        repositorioTaxaBase.save(TaxaBase.builder()
                .moeda(usd).taxaMensal(new BigDecimal("0.0040")).vigenteEm(agora).build());

        repositorioTaxaCambio.save(TaxaCambio.builder()
                .moedaBase(usd).moedaAlvo(brl).taxa(new BigDecimal("5.35000000")).vigenteEm(agora).build());
        repositorioTaxaCambio.save(TaxaCambio.builder()
                .moedaBase(brl).moedaAlvo(usd).taxa(new BigDecimal("0.18700000")).vigenteEm(agora).build());

        log.info("Seed inicial concluido.");
    }
}
