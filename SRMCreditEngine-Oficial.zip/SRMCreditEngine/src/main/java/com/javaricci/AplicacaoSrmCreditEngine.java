package com.javaricci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada da plataforma SRM Credit Engine.
 *
 * <p>Motor de aquisicao e precificacao de recebiveis multimoedas para
 * operacoes de FIDC.</p>
 *
 * <p>Nota: a resiliencia (retry/circuit breaker) em
 * {@link com.javaricci.client.ClienteTaxaCambioExterna} usa as proprias
 * anotacoes {@code @Retry}/{@code @CircuitBreaker} do Resilience4j, que sao
 * conectadas automaticamente pela autoconfiguracao do
 * {@code resilience4j-spring-boot2} junto com o {@code spring-boot-starter-aop}
 * - nao e necessario {@code @EnableRetry} (essa anotacao pertence ao projeto
 * separado Spring Retry, que nao e dependencia deste projeto).</p>
 */
@SpringBootApplication
public class AplicacaoSrmCreditEngine {

    public static void main(String[] args) {
        SpringApplication.run(AplicacaoSrmCreditEngine.class, args);
    }
}
