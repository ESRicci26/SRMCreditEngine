package com.javaricci.domain.strategy;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Template para a formula de desconto compartilhada:
 * {@code VP = ValorFace / (1 + taxaBase + spreadEfetivo)^prazo}.
 *
 * <p>As estrategias concretas so precisam decidir o spread efetivo (podem
 * somar adicionais de risco por cima do spread base do produto); a matematica
 * do valor presente em si fica aqui uma unica vez, respeitando o DRY.</p>
 */
public abstract class EstrategiaPrecificacaoAbstrata implements EstrategiaPrecificacao {

    private static final MathContext CONTEXTO_MATEMATICO = new MathContext(15, RoundingMode.HALF_UP);
    private static final int ESCALA_MONETARIA = 4;

    /**
     * Ponto de extensao para as subclasses ajustarem o spread alem do spread
     * base do produto (ex: adicional de risco para prazos maiores, ou
     * instrumentos de maior risco).
     */
    protected abstract BigDecimal resolverSpreadEfetivo(ContextoPrecificacao contexto);

    @Override
    public ResultadoPrecificacao calcular(ContextoPrecificacao contexto) {
        BigDecimal spreadEfetivo = resolverSpreadEfetivo(contexto);
        BigDecimal taxaPeriodo = contexto.getTaxaBaseMensal().add(spreadEfetivo);
        BigDecimal umMaisTaxa = BigDecimal.ONE.add(taxaPeriodo);

        BigDecimal fatorDesconto = potencia(umMaisTaxa, contexto.getPrazoMeses());

        BigDecimal valorPresente = contexto.getValorFace()
                .divide(fatorDesconto, ESCALA_MONETARIA, RoundingMode.HALF_UP);

        return ResultadoPrecificacao.builder()
                .valorPresente(valorPresente)
                .spreadEfetivoAplicado(spreadEfetivo)
                .fatorDesconto(fatorDesconto)
                .build();
    }

    /**
     * (1 + taxa) ^ prazo, suportando prazo fracionario (nao inteiro) em
     * meses, calculado via exp(prazo * ln(base)) com um MathContext fixo.
     */
    private BigDecimal potencia(BigDecimal base, BigDecimal expoente) {
        double resultado = Math.exp(expoente.doubleValue() * Math.log(base.doubleValue()));
        return new BigDecimal(resultado, CONTEXTO_MATEMATICO);
    }
}
