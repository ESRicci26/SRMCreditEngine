package com.javaricci.domain.entity;

import com.javaricci.domain.enums.StatusTransacao;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Uma aquisicao (cessao) de um unico recebivel: guarda os insumos da
 * precificacao, o valor presente calculado e os detalhes finais de liquidacao.
 *
 * <p>{@code versao} e usada para optimistic locking, de forma que tentativas
 * concorrentes de liquidacao sobre a mesma transacao falhem rapido em vez de
 * corromper silenciosamente o razao (ver requisito: "cuidado com race
 * conditions").</p>
 */
@Entity
@Table(name = "transaction_ledger")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Transacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "assignor", nullable = false, length = 120)
    private String cedente;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "receivable_type_id", nullable = false)
    private TipoRecebivel tipoRecebivel;

    @Column(name = "face_value", nullable = false, precision = 19, scale = 4)
    private BigDecimal valorFace;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "face_currency_id", nullable = false)
    private Moeda moedaFace;

    @Column(name = "due_date", nullable = false)
    private LocalDate dataVencimento;

    @Column(name = "term_months", nullable = false, precision = 9, scale = 4)
    private BigDecimal prazoMeses;

    @Column(name = "base_rate_applied", nullable = false, precision = 9, scale = 6)
    private BigDecimal taxaBaseAplicada;

    @Column(name = "spread_applied", nullable = false, precision = 9, scale = 6)
    private BigDecimal spreadAplicado;

    @Column(name = "present_value", nullable = false, precision = 19, scale = 4)
    private BigDecimal valorPresente;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "settlement_currency_id", nullable = false)
    private Moeda moedaLiquidacao;

    @Column(name = "exchange_rate_applied", precision = 19, scale = 8)
    private BigDecimal taxaCambioAplicada;

    @Column(name = "settled_value", nullable = false, precision = 19, scale = 4)
    private BigDecimal valorLiquidado;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private StatusTransacao situacao;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime criadoEm;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime atualizadoEm;

    /** Token de optimistic locking - evita liquidacao concorrente duplicada. */
    @Version
    @Column(name = "version", nullable = false)
    private Long versao;

    @PrePersist
    void aoCriar() {
        LocalDateTime agora = LocalDateTime.now();
        this.criadoEm = agora;
        this.atualizadoEm = agora;
        if (this.situacao == null) {
            this.situacao = StatusTransacao.PENDENTE;
        }
    }

    @PreUpdate
    void aoAtualizar() {
        this.atualizadoEm = LocalDateTime.now();
    }
}
