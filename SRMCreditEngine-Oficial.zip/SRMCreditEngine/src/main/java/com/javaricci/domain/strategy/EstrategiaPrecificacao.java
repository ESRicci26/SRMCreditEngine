package com.javaricci.domain.strategy;

import com.javaricci.domain.enums.CodigoTipoRecebivel;

/**
 * Padrao Strategy: desacopla a regra de risco/desagio de um produto de
 * recebivel do motor generico de calculo de valor presente
 * ({@link com.javaricci.service.ServicoPrecificacao}).
 *
 * <p>Formula base (comum a todas as estrategias):
 * {@code VP = ValorFace / (1 + taxaBase + spread)^prazo}.
 * Cada estrategia concreta e livre para ajustar o spread efetivo que alimenta
 * essa formula de acordo com o perfil de risco especifico do seu produto.</p>
 */
public interface EstrategiaPrecificacao {

    /** Qual produto de recebivel esta estrategia precifica. */
    CodigoTipoRecebivel obterCodigoTipoRecebivel();

    /** Calcula o valor presente para as entradas informadas. */
    ResultadoPrecificacao calcular(ContextoPrecificacao contexto);
}
