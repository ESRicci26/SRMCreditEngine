package com.javaricci.domain.strategy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

/**
 * Entrada imutavel para um calculo de precificacao, desacoplada das entidades
 * de persistencia para que as estrategias permanecam alheias ao JPA.
 */
@Getter
@Builder
@AllArgsConstructor
public class ContextoPrecificacao {
    private final BigDecimal valorFace;
    private final BigDecimal taxaBaseMensal;
    private final BigDecimal spreadMensal;
    private final BigDecimal prazoMeses;
}
