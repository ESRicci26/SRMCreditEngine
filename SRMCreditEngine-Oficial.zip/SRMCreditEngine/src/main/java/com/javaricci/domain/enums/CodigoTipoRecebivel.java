package com.javaricci.domain.enums;

/**
 * Identifica qual {@link com.javaricci.domain.strategy.EstrategiaPrecificacao}
 * deve ser usada para precificar um determinado produto de recebivel.
 */
public enum CodigoTipoRecebivel {
    DUPLICATA_MERCANTIL,
    CHEQUE_PRE_DATADO
}
