package com.javaricci.domain.entity;

import com.javaricci.domain.enums.CodigoMoeda;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Uma moeda reconhecida pela mesa de caixa multimoedas (BRL, USD, ...).
 */
@Entity
@Table(name = "currency", uniqueConstraints = @UniqueConstraint(columnNames = "code"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Moeda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "code", nullable = false, length = 10)
    private CodigoMoeda codigo;

    @Column(name = "name", nullable = false, length = 60)
    private String nome;

    @Column(name = "symbol", nullable = false, length = 5)
    private String simbolo;
}
