package com.javaricci.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Uma taxa de conversao entre moedas, valida a partir de um determinado instante.
 *
 * <p>{@code taxa} converte 1 unidade de {@code moedaBase} em
 * {@code moedaAlvo}, ex: USD -&gt; BRL taxa = 5.35.</p>
 */
@Entity
@Table(name = "exchange_rate")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxaCambio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "base_currency_id", nullable = false)
    private Moeda moedaBase;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "target_currency_id", nullable = false)
    private Moeda moedaAlvo;

    @Column(name = "rate", nullable = false, precision = 19, scale = 8)
    private BigDecimal taxa;

    @Column(name = "effective_at", nullable = false)
    private LocalDateTime vigenteEm;
}
