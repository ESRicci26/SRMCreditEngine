package com.javaricci.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * A taxa base livre de risco (mensal) usada como piso de desconto para uma
 * determinada moeda, ex: uma referencia estilo CDI/Selic para o BRL ou uma
 * referencia estilo SOFR para o USD. Usada pelas implementacoes de
 * {@link com.javaricci.domain.strategy.EstrategiaPrecificacao} junto com o
 * spread do produto.
 */
@Entity
@Table(name = "base_rate")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxaBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "currency_id", nullable = false)
    private Moeda moeda;

    @Column(name = "monthly_rate", nullable = false, precision = 9, scale = 6)
    private BigDecimal taxaMensal;

    @Column(name = "effective_at", nullable = false)
    private LocalDateTime vigenteEm;
}
