package com.javaricci.domain.strategy;

import com.javaricci.domain.enums.CodigoTipoRecebivel;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Regra de risco para "Duplicata Mercantil": o spread base do produto e
 * aplicado como esta, ja que e lastreada em uma fatura comercial com menor
 * risco de inadimplencia.
 */
@Component
public class EstrategiaPrecificacaoDuplicataMercantil extends EstrategiaPrecificacaoAbstrata {

    @Override
    public CodigoTipoRecebivel obterCodigoTipoRecebivel() {
        return CodigoTipoRecebivel.DUPLICATA_MERCANTIL;
    }

    @Override
    protected BigDecimal resolverSpreadEfetivo(ContextoPrecificacao contexto) {
        return contexto.getSpreadMensal();
    }
}
