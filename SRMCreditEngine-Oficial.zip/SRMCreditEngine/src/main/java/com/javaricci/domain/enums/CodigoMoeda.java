package com.javaricci.domain.enums;

/** Moedas suportadas pela mesa de caixa multimoedas. */
public enum CodigoMoeda {
    BRL,
    USD
}
