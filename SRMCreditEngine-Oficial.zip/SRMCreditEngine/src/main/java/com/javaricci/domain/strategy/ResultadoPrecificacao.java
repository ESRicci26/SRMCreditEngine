package com.javaricci.domain.strategy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

/** Saida de um calculo de {@link EstrategiaPrecificacao}, na moeda do titulo (valor de face). */
@Getter
@Builder
@AllArgsConstructor
public class ResultadoPrecificacao {
    private final BigDecimal valorPresente;
    private final BigDecimal spreadEfetivoAplicado;
    private final BigDecimal fatorDesconto;
}
