package com.javaricci.domain.strategy;

import com.javaricci.domain.enums.CodigoTipoRecebivel;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Regra de risco para "Cheque Pre-datado": alem do spread base do produto, e
 * cobrado um adicional de risco de 0,30 p.p. a.m. sempre que o prazo exceder
 * 60 dias (~2 meses), refletindo o maior risco de inadimplencia/devolucao de
 * cheques mantidos por periodos mais longos.
 */
@Component
public class EstrategiaPrecificacaoChequePreDatado extends EstrategiaPrecificacaoAbstrata {

    private static final BigDecimal LIMIAR_PRAZO_LONGO_MESES = BigDecimal.valueOf(2);
    private static final BigDecimal ADICIONAL_RISCO_PRAZO_LONGO = BigDecimal.valueOf(0.003);

    @Override
    public CodigoTipoRecebivel obterCodigoTipoRecebivel() {
        return CodigoTipoRecebivel.CHEQUE_PRE_DATADO;
    }

    @Override
    protected BigDecimal resolverSpreadEfetivo(ContextoPrecificacao contexto) {
        BigDecimal spreadBase = contexto.getSpreadMensal();
        if (contexto.getPrazoMeses().compareTo(LIMIAR_PRAZO_LONGO_MESES) > 0) {
            return spreadBase.add(ADICIONAL_RISCO_PRAZO_LONGO);
        }
        return spreadBase;
    }
}
