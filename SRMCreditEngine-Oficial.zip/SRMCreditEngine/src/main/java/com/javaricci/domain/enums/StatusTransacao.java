package com.javaricci.domain.enums;

/** Ciclo de vida de uma transacao de aquisicao de recebivel. */
public enum StatusTransacao {
    PENDENTE,
    LIQUIDADA,
    CANCELADA
}
