package com.javaricci.domain.entity;

import com.javaricci.domain.enums.CodigoTipoRecebivel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.math.BigDecimal;

/**
 * Um produto de recebivel (ex: "Duplicata Mercantil", "Cheque Pre-datado") com
 * seu spread de risco mensal base. A regra de precificacao concreta do tipo e
 * resolvida em tempo de execucao via o padrao Strategy
 * ({@link com.javaricci.domain.strategy.FabricaEstrategiaPrecificacao}).
 */
@Entity
@Table(name = "receivable_type", uniqueConstraints = @UniqueConstraint(columnNames = "code"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TipoRecebivel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "code", nullable = false, length = 40)
    private CodigoTipoRecebivel codigo;

    @Column(name = "description", nullable = false, length = 80)
    private String descricao;

    /** Spread de risco mensal base, ex: 0.015 para 1.5% a.m. */
    @Column(name = "monthly_spread", nullable = false, precision = 9, scale = 6)
    private BigDecimal spreadMensal;
}
