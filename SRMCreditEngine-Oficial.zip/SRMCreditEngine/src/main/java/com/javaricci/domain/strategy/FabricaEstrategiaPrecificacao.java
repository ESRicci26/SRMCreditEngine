package com.javaricci.domain.strategy;

import com.javaricci.domain.enums.CodigoTipoRecebivel;
import com.javaricci.exception.ExcecaoNegocio;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Resolve a implementacao correta de {@link EstrategiaPrecificacao} para um
 * determinado tipo de recebivel em tempo de execucao, mantendo os
 * chamadores desacoplados das classes de estrategia concretas (padrao
 * Strategy + Factory simples).
 */
@Component
public class FabricaEstrategiaPrecificacao {

    private final Map<CodigoTipoRecebivel, EstrategiaPrecificacao> estrategiasPorTipo;

    public FabricaEstrategiaPrecificacao(List<EstrategiaPrecificacao> estrategias) {
        this.estrategiasPorTipo = estrategias.stream()
                .collect(Collectors.toMap(EstrategiaPrecificacao::obterCodigoTipoRecebivel, Function.identity()));
    }

    public EstrategiaPrecificacao resolver(CodigoTipoRecebivel codigo) {
        EstrategiaPrecificacao estrategia = estrategiasPorTipo.get(codigo);
        if (estrategia == null) {
            throw new ExcecaoNegocio("Nenhuma estrategia de precificacao registrada para o tipo: " + codigo);
        }
        return estrategia;
    }
}
