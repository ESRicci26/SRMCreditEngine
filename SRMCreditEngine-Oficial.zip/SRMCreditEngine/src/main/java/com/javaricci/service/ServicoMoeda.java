package com.javaricci.service;

import com.javaricci.client.ClienteTaxaCambioExterna;
import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TaxaCambio;
import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.dto.request.RequisicaoTaxaCambioDto;
import com.javaricci.exception.ExcecaoNegocio;
import com.javaricci.exception.ExcecaoRecursoNaoEncontrado;
import com.javaricci.repository.RepositorioMoeda;
import com.javaricci.repository.RepositorioTaxaCambio;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Servico de aplicacao/negocio para moedas e taxas de cambio
 * (requisito Currency Engine).
 */
@Service
public class ServicoMoeda {

    private static final Logger log = LoggerFactory.getLogger(ServicoMoeda.class);

    private final RepositorioMoeda repositorioMoeda;
    private final RepositorioTaxaCambio repositorioTaxaCambio;
    private final ClienteTaxaCambioExterna clienteTaxaCambioExterna;

    public ServicoMoeda(RepositorioMoeda repositorioMoeda,
                         RepositorioTaxaCambio repositorioTaxaCambio,
                         ClienteTaxaCambioExterna clienteTaxaCambioExterna) {
        this.repositorioMoeda = repositorioMoeda;
        this.repositorioTaxaCambio = repositorioTaxaCambio;
        this.clienteTaxaCambioExterna = clienteTaxaCambioExterna;
    }

    public List<Moeda> listarMoedas() {
        return repositorioMoeda.findAll();
    }

    public Moeda buscarPorCodigo(CodigoMoeda codigo) {
        return repositorioMoeda.findByCodigo(codigo)
                .orElseThrow(() -> new ExcecaoRecursoNaoEncontrado("Moeda nao cadastrada: " + codigo));
    }

    public List<TaxaCambio> listarTaxas() {
        return repositorioTaxaCambio.findAllByOrderByVigenteEmDesc();
    }

    /** Atualizacao/registro manual de uma taxa de cambio (requisito: "atualizacao manual" de taxas). */
    @Transactional
    public TaxaCambio atualizarTaxa(RequisicaoTaxaCambioDto requisicao) {
        if (requisicao.getMoedaBase() == requisicao.getMoedaAlvo()) {
            throw new ExcecaoNegocio("Moeda base e moeda alvo nao podem ser iguais.");
        }
        Moeda base = buscarPorCodigo(requisicao.getMoedaBase());
        Moeda alvo = buscarPorCodigo(requisicao.getMoedaAlvo());

        TaxaCambio salva = repositorioTaxaCambio.save(TaxaCambio.builder()
                .moedaBase(base)
                .moedaAlvo(alvo)
                .taxa(requisicao.getTaxa())
                .vigenteEm(LocalDateTime.now())
                .build());
        log.info("Taxa de cambio atualizada: {} -> {} = {}", base.getCodigo(), alvo.getCodigo(), requisicao.getTaxa());
        return salva;
    }

    /**
     * Resolve a taxa mais recente para converter 1 unidade de {@code origem}
     * em {@code destino}. Tenta primeiro o provedor externo (mockado) via um
     * cliente resiliente, recorrendo a ultima taxa persistida localmente e,
     * por fim, derivando o inverso a partir do par reverso se necessario.
     */
    public BigDecimal resolverTaxaConversao(CodigoMoeda origem, CodigoMoeda destino) {
        if (origem == destino) {
            return BigDecimal.ONE;
        }
        Moeda moedaOrigem = buscarPorCodigo(origem);
        Moeda moedaDestino = buscarPorCodigo(destino);

        BigDecimal taxaExterna = clienteTaxaCambioExterna.buscarTaxaMaisRecente(origem.name(), destino.name());
        if (taxaExterna != null) {
            return taxaExterna;
        }

        return repositorioTaxaCambio
                .findFirstByMoedaBaseAndMoedaAlvoOrderByVigenteEmDesc(moedaOrigem, moedaDestino)
                .map(TaxaCambio::getTaxa)
                .orElseGet(() -> repositorioTaxaCambio
                        .findFirstByMoedaBaseAndMoedaAlvoOrderByVigenteEmDesc(moedaDestino, moedaOrigem)
                        .map(taxaCambio -> BigDecimal.ONE.divide(taxaCambio.getTaxa(), new MathContext(15)))
                        .orElseThrow(() -> new ExcecaoNegocio(
                                "Nenhuma taxa de cambio cadastrada para o par " + origem + "/" + destino)));
    }
}
