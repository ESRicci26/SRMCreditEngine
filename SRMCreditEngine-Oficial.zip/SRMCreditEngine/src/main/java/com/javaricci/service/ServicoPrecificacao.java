package com.javaricci.service;

import com.javaricci.domain.entity.TaxaBase;
import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TipoRecebivel;
import com.javaricci.domain.strategy.ContextoPrecificacao;
import com.javaricci.domain.strategy.ResultadoPrecificacao;
import com.javaricci.domain.strategy.EstrategiaPrecificacao;
import com.javaricci.domain.strategy.FabricaEstrategiaPrecificacao;
import com.javaricci.dto.request.RequisicaoSimulacaoDto;
import com.javaricci.dto.response.RespostaSimulacaoPrecificacaoDto;
import com.javaricci.exception.ExcecaoNegocio;
import com.javaricci.repository.RepositorioTaxaBase;
import com.javaricci.repository.RepositorioTipoRecebivel;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Motor de Precificacao: resolve a {@link EstrategiaPrecificacao} correta
 * para o tipo de recebivel, aplica a formula de desconto (taxa base +
 * spread) e converte o resultado para a moeda de liquidacao quando a
 * operacao e cross-currency.
 *
 * <p>Formula: {@code VP = ValorFace / (1 + taxaBase + spread)^prazo}.
 * Se a moeda de liquidacao for diferente da moeda do titulo, a conversao
 * cambial e aplicada por cima do valor presente (conforme especificado).</p>
 */
@Service
public class ServicoPrecificacao {

    private static final int ESCALA_PRAZO = 4;
    private static final int ESCALA_MONETARIA = 4;
    private static final BigDecimal DIAS_POR_MES = BigDecimal.valueOf(30);

    private final FabricaEstrategiaPrecificacao fabricaEstrategia;
    private final RepositorioTipoRecebivel repositorioTipoRecebivel;
    private final RepositorioTaxaBase repositorioTaxaBase;
    private final ServicoMoeda servicoMoeda;

    public ServicoPrecificacao(FabricaEstrategiaPrecificacao fabricaEstrategia,
                                RepositorioTipoRecebivel repositorioTipoRecebivel,
                                RepositorioTaxaBase repositorioTaxaBase,
                                ServicoMoeda servicoMoeda) {
        this.fabricaEstrategia = fabricaEstrategia;
        this.repositorioTipoRecebivel = repositorioTipoRecebivel;
        this.repositorioTaxaBase = repositorioTaxaBase;
        this.servicoMoeda = servicoMoeda;
    }

    /**
     * Executa uma simulacao de precificacao completa para as entradas
     * informadas. Usada tanto pelo painel "e se" em tempo real do operador
     * quanto internamente ao criar uma transacao persistida.
     */
    public RespostaSimulacaoPrecificacaoDto simular(RequisicaoSimulacaoDto requisicao) {
        if (!requisicao.getDataVencimento().isAfter(LocalDate.now())) {
            throw new ExcecaoNegocio("Data de vencimento deve ser futura em relacao a data de operacao.");
        }

        TipoRecebivel tipoRecebivel = repositorioTipoRecebivel.findByCodigo(requisicao.getTipoRecebivel())
                .orElseThrow(() -> new ExcecaoNegocio(
                        "Tipo de recebivel nao cadastrado: " + requisicao.getTipoRecebivel()));

        Moeda moedaFace = servicoMoeda.buscarPorCodigo(requisicao.getMoedaFace());

        TaxaBase taxaBase = repositorioTaxaBase.findFirstByMoedaOrderByVigenteEmDesc(moedaFace)
                .orElseThrow(() -> new ExcecaoNegocio(
                        "Nenhuma taxa base cadastrada para a moeda: " + requisicao.getMoedaFace()));

        BigDecimal prazoMeses = calcularPrazoMeses(requisicao.getDataVencimento());

        EstrategiaPrecificacao estrategia = fabricaEstrategia.resolver(requisicao.getTipoRecebivel());
        ContextoPrecificacao contexto = ContextoPrecificacao.builder()
                .valorFace(requisicao.getValorFace())
                .taxaBaseMensal(taxaBase.getTaxaMensal())
                .spreadMensal(tipoRecebivel.getSpreadMensal())
                .prazoMeses(prazoMeses)
                .build();

        ResultadoPrecificacao resultado = estrategia.calcular(contexto);

        BigDecimal taxaCambioAplicada = null;
        BigDecimal valorLiquidado = resultado.getValorPresente();

        if (requisicao.getMoedaFace() != requisicao.getMoedaLiquidacao()) {
            taxaCambioAplicada = servicoMoeda.resolverTaxaConversao(
                    requisicao.getMoedaFace(), requisicao.getMoedaLiquidacao());
            valorLiquidado = resultado.getValorPresente()
                    .multiply(taxaCambioAplicada)
                    .setScale(ESCALA_MONETARIA, RoundingMode.HALF_UP);
        }

        return RespostaSimulacaoPrecificacaoDto.builder()
                .valorFace(requisicao.getValorFace())
                .prazoMeses(prazoMeses)
                .taxaBaseAplicada(taxaBase.getTaxaMensal())
                .spreadAplicado(resultado.getSpreadEfetivoAplicado())
                .valorPresenteMoedaFace(resultado.getValorPresente())
                .taxaCambioAplicada(taxaCambioAplicada)
                .valorLiquidado(valorLiquidado)
                .moedaFace(requisicao.getMoedaFace().name())
                .moedaLiquidacao(requisicao.getMoedaLiquidacao().name())
                .build();
    }

    /** Prazo em meses (convencao de 30 dias), como valor fracionario para precisao. */
    private BigDecimal calcularPrazoMeses(LocalDate dataVencimento) {
        long dias = ChronoUnit.DAYS.between(LocalDate.now(), dataVencimento);
        return BigDecimal.valueOf(dias).divide(DIAS_POR_MES, ESCALA_PRAZO, RoundingMode.HALF_UP);
    }
}
