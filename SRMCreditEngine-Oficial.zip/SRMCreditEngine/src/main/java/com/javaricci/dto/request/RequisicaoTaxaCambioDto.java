package com.javaricci.dto.request;

import com.javaricci.domain.enums.CodigoMoeda;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/** Atualizacao manual de uma taxa de cambio entre duas moedas. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequisicaoTaxaCambioDto {

    @NotNull
    private CodigoMoeda moedaBase;

    @NotNull
    private CodigoMoeda moedaAlvo;

    @NotNull
    @DecimalMin(value = "0.00000001", message = "taxa deve ser positiva")
    private BigDecimal taxa;
}
