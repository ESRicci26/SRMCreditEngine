package com.javaricci.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Modelo de leitura completo de uma transacao persistida. */
@Getter
@Builder
@AllArgsConstructor
public class RespostaTransacaoDto {
    private Long id;
    private String cedente;
    private String tipoRecebivel;
    private BigDecimal valorFace;
    private String moedaFace;
    private LocalDate dataVencimento;
    private BigDecimal prazoMeses;
    private BigDecimal taxaBaseAplicada;
    private BigDecimal spreadAplicado;
    private BigDecimal valorPresente;
    private String moedaLiquidacao;
    private BigDecimal taxaCambioAplicada;
    private BigDecimal valorLiquidado;
    private String situacao;
    private Long versao;
    private LocalDateTime criadoEm;
    private LocalDateTime atualizadoEm;
}
