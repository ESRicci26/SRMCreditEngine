package com.javaricci.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

/** Resultado de uma simulacao de precificacao em tempo real, na moeda do titulo e na moeda de liquidacao. */
@Getter
@Builder
@AllArgsConstructor
public class RespostaSimulacaoPrecificacaoDto {
    private BigDecimal valorFace;
    private BigDecimal prazoMeses;
    private BigDecimal taxaBaseAplicada;
    private BigDecimal spreadAplicado;
    private BigDecimal valorPresenteMoedaFace;
    private BigDecimal taxaCambioAplicada;
    private BigDecimal valorLiquidado;
    private String moedaFace;
    private String moedaLiquidacao;
}
