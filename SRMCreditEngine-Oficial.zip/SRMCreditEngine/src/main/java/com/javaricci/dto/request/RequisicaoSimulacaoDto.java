package com.javaricci.dto.request;

import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.CodigoTipoRecebivel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Entrada para uma simulacao de precificacao (sem persistir) ou para criar uma transacao real. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequisicaoSimulacaoDto {

    @NotNull(message = "cedente e obrigatorio")
    private String cedente;

    @NotNull(message = "tipo de recebivel e obrigatorio")
    private CodigoTipoRecebivel tipoRecebivel;

    @NotNull(message = "valor de face e obrigatorio")
    @DecimalMin(value = "0.01", message = "valor de face deve ser positivo")
    private BigDecimal valorFace;

    @NotNull(message = "moeda do titulo e obrigatoria")
    private CodigoMoeda moedaFace;

    @NotNull(message = "moeda de liquidacao e obrigatoria")
    private CodigoMoeda moedaLiquidacao;

    @NotNull(message = "data de vencimento e obrigatoria")
    @Future(message = "data de vencimento deve ser futura")
    private LocalDate dataVencimento;
}
