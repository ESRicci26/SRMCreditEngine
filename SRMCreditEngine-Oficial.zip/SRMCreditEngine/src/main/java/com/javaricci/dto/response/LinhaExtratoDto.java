package com.javaricci.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Uma linha do relatorio analitico "Extrato de Liquidacao". */
@Getter
@Builder
@AllArgsConstructor
public class LinhaExtratoDto {
    private Long id;
    private String cedente;
    private String tipoRecebivel;
    private BigDecimal valorFace;
    private String moedaFace;
    private String moedaLiquidacao;
    private LocalDate dataVencimento;
    private BigDecimal valorPresente;
    private BigDecimal valorLiquidado;
    private String situacao;
}
