package com.javaricci.client;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Integracao simulada com um provedor externo de taxas de cambio.
 *
 * <p>Mesas reais dependem de feeds de cambio de terceiros que ocasionalmente
 * falham ou dao timeout; este mock falha aleatoriamente ~30% das vezes para
 * exercitar as politicas de resiliencia {@code @Retry} + {@code @CircuitBreaker}
 * (configuradas em application.yml sob {@code resilience4j.*}) em vez de
 * deixar uma falha transitoria derrubar a precificacao.</p>
 */
@Component
public class ClienteTaxaCambioExterna {

    private static final Logger log = LoggerFactory.getLogger(ClienteTaxaCambioExterna.class);

    @Retry(name = "fxRateProvider", fallbackMethod = "taxaContingencia")
    @CircuitBreaker(name = "fxRateProvider", fallbackMethod = "taxaContingencia")
    public BigDecimal buscarTaxaMaisRecente(String moedaBase, String moedaAlvo) {
        log.info("Consultando provedor externo de cambio: {} -> {}", moedaBase, moedaAlvo);
        if (ThreadLocalRandom.current().nextInt(100) < 30) {
            throw new IllegalStateException("Provedor externo de cambio indisponivel (timeout simulado)");
        }
        // Em uma integracao real, aqui seria feita a chamada HTTP ao provedor externo.
        return null;
    }

    /**
     * Metodo de contingencia acionado quando as tentativas se esgotam ou o
     * circuito esta aberto: recorre a ultima taxa persistida localmente em
     * vez de falhar toda a requisicao de precificacao.
     */
    private BigDecimal taxaContingencia(String moedaBase, String moedaAlvo, Throwable causa) {
        log.warn("Contingencia acionada para taxa de cambio {} -> {}: usando ultima taxa local persistida. Causa: {}",
                moedaBase, moedaAlvo, causa.getMessage());
        return null;
    }
}
