package com.javaricci.controller;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TaxaCambio;
import com.javaricci.dto.request.RequisicaoTaxaCambioDto;
import com.javaricci.service.ServicoMoeda;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/** Currency Engine: moedas e taxas de cambio. */
@RestController
@RequestMapping("/api/currencies")
@Tag(name = "Currency Engine", description = "Gestao de moedas e taxas de cambio")
public class ControladorMoeda {

    private final ServicoMoeda servicoMoeda;

    public ControladorMoeda(ServicoMoeda servicoMoeda) {
        this.servicoMoeda = servicoMoeda;
    }

    @GetMapping
    @Operation(summary = "Lista as moedas cadastradas")
    public ResponseEntity<List<Moeda>> listar() {
        return ResponseEntity.ok(servicoMoeda.listarMoedas());
    }

    @GetMapping("/rates")
    @Operation(summary = "Lista o historico de taxas de cambio cadastradas")
    public ResponseEntity<List<TaxaCambio>> listarTaxas() {
        return ResponseEntity.ok(servicoMoeda.listarTaxas());
    }

    @PostMapping("/rates")
    @Operation(summary = "Registra/atualiza manualmente uma taxa de cambio entre duas moedas")
    public ResponseEntity<TaxaCambio> atualizarTaxa(@Valid @RequestBody RequisicaoTaxaCambioDto requisicao) {
        TaxaCambio salva = servicoMoeda.atualizarTaxa(requisicao);
        return ResponseEntity.status(HttpStatus.CREATED).body(salva);
    }
}
