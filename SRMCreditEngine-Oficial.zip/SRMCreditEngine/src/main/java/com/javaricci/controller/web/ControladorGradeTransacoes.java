package com.javaricci.controller.web;

import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.StatusTransacao;
import com.javaricci.dto.response.RespostaTransacaoDto;
import com.javaricci.service.ServicoTransacao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

/**
 * Grade de Transacoes: tabela com paginacao server-side e filtros dinamicos,
 * renderizada em Thymeleaf (sem necessidade de um framework de grid em JS).
 */
@Controller
public class ControladorGradeTransacoes {

    private final ServicoTransacao servicoTransacao;

    public ControladorGradeTransacoes(ServicoTransacao servicoTransacao) {
        this.servicoTransacao = servicoTransacao;
    }

    @GetMapping("/transacoes")
    public String grade(
            @RequestParam(required = false) String cedente,
            @RequestParam(required = false) String moeda,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fim,
            @RequestParam(required = false) StatusTransacao situacao,
            @RequestParam(defaultValue = "0") int pagina,
            Model modelo) {

        PageRequest paginacao = PageRequest.of(pagina, 15, Sort.by(Sort.Direction.DESC, "criadoEm"));
        Page<RespostaTransacaoDto> resultado =
                servicoTransacao.buscar(cedente, moeda, inicio, fim, situacao, paginacao);

        modelo.addAttribute("pagina", resultado);
        modelo.addAttribute("moedas", CodigoMoeda.values());
        modelo.addAttribute("situacoes", StatusTransacao.values());
        modelo.addAttribute("cedente", cedente);
        modelo.addAttribute("moeda", moeda);
        modelo.addAttribute("inicio", inicio);
        modelo.addAttribute("fim", fim);
        modelo.addAttribute("situacao", situacao);
        return "transactions";
    }
}
