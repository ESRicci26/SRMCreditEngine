package com.javaricci.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Dashboard / pagina inicial. */
@Controller
public class ControladorInicio {

    @GetMapping("/")
    public String inicio() {
        return "index";
    }
}
