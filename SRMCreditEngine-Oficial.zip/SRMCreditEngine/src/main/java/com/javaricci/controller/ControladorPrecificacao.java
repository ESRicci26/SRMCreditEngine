package com.javaricci.controller;

import com.javaricci.dto.request.RequisicaoSimulacaoDto;
import com.javaricci.dto.response.RespostaSimulacaoPrecificacaoDto;
import com.javaricci.service.ServicoPrecificacao;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/** Motor de Precificacao: simulacoes em tempo real, sem persistencia (padrao Strategy por baixo). */
@RestController
@RequestMapping("/api/pricing")
@Tag(name = "Pricing Engine", description = "Simulacao de precificacao (deságio) de recebiveis")
public class ControladorPrecificacao {

    private final ServicoPrecificacao servicoPrecificacao;

    public ControladorPrecificacao(ServicoPrecificacao servicoPrecificacao) {
        this.servicoPrecificacao = servicoPrecificacao;
    }

    @PostMapping("/simulate")
    @Operation(summary = "Simula o valor presente de um recebivel sem persistir nada")
    public ResponseEntity<RespostaSimulacaoPrecificacaoDto> simular(@Valid @RequestBody RequisicaoSimulacaoDto requisicao) {
        return ResponseEntity.ok(servicoPrecificacao.simular(requisicao));
    }
}
