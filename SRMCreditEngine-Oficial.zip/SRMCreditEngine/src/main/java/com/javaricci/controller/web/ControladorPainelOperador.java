package com.javaricci.controller.web;

import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.CodigoTipoRecebivel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Painel do Operador: input do recebivel + calculo em tempo real (via JS/fetch). */
@Controller
public class ControladorPainelOperador {

    @GetMapping("/operador")
    public String painelOperador(Model modelo) {
        modelo.addAttribute("moedas", CodigoMoeda.values());
        modelo.addAttribute("tiposRecebivel", CodigoTipoRecebivel.values());
        return "operator";
    }
}
