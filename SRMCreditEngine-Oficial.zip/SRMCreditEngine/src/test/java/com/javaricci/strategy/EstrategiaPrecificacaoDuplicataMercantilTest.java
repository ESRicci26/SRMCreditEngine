package com.javaricci.strategy;

import com.javaricci.domain.strategy.EstrategiaPrecificacaoDuplicataMercantil;
import com.javaricci.domain.strategy.ContextoPrecificacao;
import com.javaricci.domain.strategy.ResultadoPrecificacao;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class EstrategiaPrecificacaoDuplicataMercantilTest {

    private final EstrategiaPrecificacaoDuplicataMercantil estrategia = new EstrategiaPrecificacaoDuplicataMercantil();

    @Test
    void deveAplicarSpreadBaseSemNenhumAdicional() {
        ContextoPrecificacao contexto = ContextoPrecificacao.builder()
                .valorFace(new BigDecimal("10000.00"))
                .taxaBaseMensal(new BigDecimal("0.009"))
                .spreadMensal(new BigDecimal("0.015"))
                .prazoMeses(new BigDecimal("2"))
                .build();

        ResultadoPrecificacao resultado = estrategia.calcular(contexto);

        assertThat(resultado.getSpreadEfetivoAplicado()).isEqualByComparingTo("0.015");
        // VP = 10000 / (1.024)^2 ~= 9535.75
        assertThat(resultado.getValorPresente().doubleValue()).isCloseTo(9535.75, within(1.0));
    }

    @Test
    void prazoMaiorDeveGerarValorPresenteMenor() {
        ContextoPrecificacao prazoCurto = ContextoPrecificacao.builder()
                .valorFace(new BigDecimal("10000.00"))
                .taxaBaseMensal(new BigDecimal("0.009"))
                .spreadMensal(new BigDecimal("0.015"))
                .prazoMeses(new BigDecimal("1"))
                .build();
        ContextoPrecificacao prazoLongo = ContextoPrecificacao.builder()
                .valorFace(new BigDecimal("10000.00"))
                .taxaBaseMensal(new BigDecimal("0.009"))
                .spreadMensal(new BigDecimal("0.015"))
                .prazoMeses(new BigDecimal("6"))
                .build();

        BigDecimal vpCurto = estrategia.calcular(prazoCurto).getValorPresente();
        BigDecimal vpLongo = estrategia.calcular(prazoLongo).getValorPresente();

        assertThat(vpLongo).isLessThan(vpCurto);
    }
}
