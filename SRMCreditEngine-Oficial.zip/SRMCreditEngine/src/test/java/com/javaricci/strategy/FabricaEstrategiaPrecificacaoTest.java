package com.javaricci.strategy;

import com.javaricci.domain.enums.CodigoTipoRecebivel;
import com.javaricci.domain.strategy.EstrategiaPrecificacaoChequePreDatado;
import com.javaricci.domain.strategy.EstrategiaPrecificacaoDuplicataMercantil;
import com.javaricci.domain.strategy.EstrategiaPrecificacao;
import com.javaricci.domain.strategy.FabricaEstrategiaPrecificacao;
import com.javaricci.exception.ExcecaoNegocio;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FabricaEstrategiaPrecificacaoTest {

    private final FabricaEstrategiaPrecificacao fabrica = new FabricaEstrategiaPrecificacao(
            List.of(new EstrategiaPrecificacaoDuplicataMercantil(), new EstrategiaPrecificacaoChequePreDatado()));

    @Test
    void deveResolverEstrategiaCorretaPorTipoDeRecebivel() {
        EstrategiaPrecificacao duplicata = fabrica.resolver(CodigoTipoRecebivel.DUPLICATA_MERCANTIL);
        EstrategiaPrecificacao cheque = fabrica.resolver(CodigoTipoRecebivel.CHEQUE_PRE_DATADO);

        assertThat(duplicata).isInstanceOf(EstrategiaPrecificacaoDuplicataMercantil.class);
        assertThat(cheque).isInstanceOf(EstrategiaPrecificacaoChequePreDatado.class);
    }

    @Test
    void deveLancarExcecaoNegocioQuandoNenhumaEstrategiaEstiverRegistrada() {
        FabricaEstrategiaPrecificacao fabricaVazia = new FabricaEstrategiaPrecificacao(List.of());
        assertThatThrownBy(() -> fabricaVazia.resolver(CodigoTipoRecebivel.DUPLICATA_MERCANTIL))
                .isInstanceOf(ExcecaoNegocio.class);
    }
}
