package com.javaricci.strategy;

import com.javaricci.domain.strategy.EstrategiaPrecificacaoChequePreDatado;
import com.javaricci.domain.strategy.ContextoPrecificacao;
import com.javaricci.domain.strategy.ResultadoPrecificacao;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class EstrategiaPrecificacaoChequePreDatadoTest {

    private final EstrategiaPrecificacaoChequePreDatado estrategia = new EstrategiaPrecificacaoChequePreDatado();

    @Test
    void naoDeveAdicionarRiscoParaPrazosCurtos() {
        ContextoPrecificacao contexto = contextoBase(new BigDecimal("1"));
        ResultadoPrecificacao resultado = estrategia.calcular(contexto);
        assertThat(resultado.getSpreadEfetivoAplicado()).isEqualByComparingTo("0.025");
    }

    @Test
    void deveAdicionarRiscoParaPrazosAlemDeDoisMeses() {
        ContextoPrecificacao contexto = contextoBase(new BigDecimal("3"));
        ResultadoPrecificacao resultado = estrategia.calcular(contexto);
        // 0.025 base + 0.003 adicional
        assertThat(resultado.getSpreadEfetivoAplicado()).isEqualByComparingTo("0.028");
    }

    private ContextoPrecificacao contextoBase(BigDecimal prazoMeses) {
        return ContextoPrecificacao.builder()
                .valorFace(new BigDecimal("5000.00"))
                .taxaBaseMensal(new BigDecimal("0.009"))
                .spreadMensal(new BigDecimal("0.025"))
                .prazoMeses(prazoMeses)
                .build();
    }
}
