package com.javaricci.service;

import com.javaricci.domain.entity.Moeda;
import com.javaricci.domain.entity.TipoRecebivel;
import com.javaricci.domain.entity.Transacao;
import com.javaricci.domain.enums.CodigoMoeda;
import com.javaricci.domain.enums.CodigoTipoRecebivel;
import com.javaricci.domain.enums.StatusTransacao;
import com.javaricci.exception.ExcecaoNegocio;
import com.javaricci.exception.ExcecaoLiquidacaoConcorrente;
import com.javaricci.exception.ExcecaoRecursoNaoEncontrado;
import com.javaricci.repository.RepositorioTipoRecebivel;
import com.javaricci.repository.RepositorioTransacao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ServicoTransacaoLiquidacaoTest {

    @Mock
    private RepositorioTransacao repositorioTransacao;
    @Mock
    private RepositorioTipoRecebivel repositorioTipoRecebivel;
    @Mock
    private ServicoMoeda servicoMoeda;
    @Mock
    private ServicoPrecificacao servicoPrecificacao;

    private ServicoTransacao servicoTransacao;

    @BeforeEach
    void configurar() {
        servicoTransacao = new ServicoTransacao(
                repositorioTransacao, repositorioTipoRecebivel, servicoMoeda, servicoPrecificacao);
    }

    @Test
    void deveRejeitarLiquidacaoQuandoVersaoNaoBate() {
        Transacao transacao = construirTransacaoPendente(3L);
        when(repositorioTransacao.findById(1L)).thenReturn(Optional.of(transacao));

        assertThatThrownBy(() -> servicoTransacao.liquidar(1L, 2L))
                .isInstanceOf(ExcecaoLiquidacaoConcorrente.class);
    }

    @Test
    void deveRejeitarLiquidacaoDeTransacaoJaLiquidada() {
        Transacao transacao = construirTransacaoPendente(1L);
        transacao.setSituacao(StatusTransacao.LIQUIDADA);
        when(repositorioTransacao.findById(1L)).thenReturn(Optional.of(transacao));

        assertThatThrownBy(() -> servicoTransacao.liquidar(1L, 1L))
                .isInstanceOf(ExcecaoNegocio.class);
    }

    @Test
    void deveLancarNaoEncontradoQuandoTransacaoNaoExiste() {
        when(repositorioTransacao.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> servicoTransacao.liquidar(99L, null))
                .isInstanceOf(ExcecaoRecursoNaoEncontrado.class);
    }

    private Transacao construirTransacaoPendente(Long versao) {
        Moeda brl = Moeda.builder().id(1L).codigo(CodigoMoeda.BRL).nome("Real").simbolo("R$").build();
        TipoRecebivel tipo = TipoRecebivel.builder()
                .id(1L).codigo(CodigoTipoRecebivel.DUPLICATA_MERCANTIL)
                .descricao("Duplicata Mercantil").spreadMensal(new BigDecimal("0.015")).build();

        return Transacao.builder()
                .id(1L)
                .cedente("Empresa XPTO")
                .tipoRecebivel(tipo)
                .valorFace(new BigDecimal("1000.00"))
                .moedaFace(brl)
                .dataVencimento(LocalDate.now().plusMonths(2))
                .prazoMeses(new BigDecimal("2"))
                .taxaBaseAplicada(new BigDecimal("0.009"))
                .spreadAplicado(new BigDecimal("0.015"))
                .valorPresente(new BigDecimal("953.57"))
                .moedaLiquidacao(brl)
                .valorLiquidado(new BigDecimal("953.57"))
                .situacao(StatusTransacao.PENDENTE)
                .versao(versao)
                .build();
    }
}
