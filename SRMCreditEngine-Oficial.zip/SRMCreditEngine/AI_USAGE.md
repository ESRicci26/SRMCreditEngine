# AI_USAGE.md

## Ferramenta utilizada
Claude (Anthropic), via chat, atuando como co-piloto de engenharia para scaffolding, geracao de
boilerplate e revisao de decisoes de design.

## Prompts estrategicos utilizados (resumo)

1. **Scaffolding inicial da estrutura do projeto** a partir do README do desafio: geracao da
   estrutura de pacotes (`domain`, `service`, `repository`, `controller`, `dto`, `exception`),
   entidades JPA, DTOs e esqueleto do `pom.xml` com as dependencias (Spring Boot 2.7 + Java 11,
   SQLite via `sqlite-jdbc`, Resilience4j, springdoc-openapi).
2. **Strategy Pattern para o motor de precificacao**: prompt especifico pedindo a separacao entre
   a formula generica de valor presente (`EstrategiaPrecificacaoAbstrata`) e a regra de risco de cada
   produto (`EstrategiaPrecificacaoDuplicataMercantil`, `EstrategiaPrecificacaoChequePreDatado`), evitando que a
   IA colapsasse tudo em um unico `if/else` dentro do service.
3. **Geracao de massa de dados inicial (seed)**: prompt para criar um `SemeadorDados` idempotente
   com moedas, tipos de recebivel, taxas base e taxa de cambio inicial, evitando a necessidade de
   popular tudo manualmente antes de testar a API.
4. **Refatoracao da camada de relatorios para 2 camadas**: pedido explicito para que
   `ControladorRelatorio` conversasse diretamente com um repositorio baseado em
   `NamedParameterJdbcTemplate` (SQL nativo), sem passar pela camada de service, conforme
   exigido no requisito 6 do desafio.
5. **Front-end Thymeleaf**: prompts para gerar o painel do operador com calculo em tempo real
   (fetch + debounce em JS puro) e o grid de transacoes com paginacao/filtros server-side.
6. **Diagramas C4 e ER em Mermaid**, DDL documental e workflow de CI (GitHub Actions).

## Trechos onde a IA alucinou ou gerou algo que precisou de correcao

- **Dialect do Hibernate para SQLite (duas rodadas de erro da IA):** a primeira sugestao foi
  usar uma dependencia antiga/descontinuada de terceiros (`com.enigmabridge:hibernate4-sqlite-dialect`,
  baseada em Hibernate 4.3), incompativel com Hibernate 5.6/Spring Boot 2.7. A "correcao" seguinte
  da IA tambem estava errada: sugeriu `org.hibernate:hibernate-community-dialects:5.6.15.Final`
  (que traria `org.hibernate.community.dialect.SQLiteDialect` pronto) - esse artefato **nao existe
  para a serie 5.x do Hibernate**, apenas a partir do Hibernate ORM 6 (sob o groupId
  `org.hibernate.orm`), o que so foi percebido ao tentar importar o projeto e ver o erro de
  "Missing artifact" no Maven. A correcao definitiva foi abandonar dependencias externas para o
  dialect e escrever um `com.javaricci.config.DialetoSQLite` proprio, minimo, sobre a API estavel
  de `org.hibernate.dialect.Dialect` (ja presente em `hibernate-core`), eliminando o risco de
  desalinhamento de versao. Isso reforca que qualquer dependencia sugerida por IA - especialmente
  combinacoes de groupId/artifactId/versao pouco comuns - precisa ser conferida manualmente no
  repositorio antes de ser aceita, mesmo quando a sugestao parece plausivel.
- **Dialect customizado com metodo que nao existe mais (3a rodada do mesmo problema):** ao
  escrever o `DialetoSQLite` proprio (item acima), a IA sobrescreveu `Dialect.supportsIdentityColumns()`
  supondo que esse atalho ainda existisse diretamente na classe `Dialect`. Na compilacao real
  (fora deste ambiente de sandbox, que nao tem acesso ao Maven Central para validar), o erro
  "must override or implement a supertype method" mostrou que esse metodo foi removido da classe
  `Dialect` em Hibernate 5.6.x - o suporte a identity columns passou a ser resolvido
  exclusivamente via `getIdentityColumnSupport().supportsIdentityColumns()` (que ja estava
  implementado corretamente na classe interna). A correcao foi simplesmente remover a
  sobrescrita redundante e desatualizada.
- **`@EnableRetry` sem a dependencia correspondente:** a classe principal foi anotada com
  `@EnableRetry` (do projeto Spring Retry), mas o `pom.xml` nunca teve essa dependencia - o
  projeto usa as anotacoes proprias do Resilience4j (`@Retry`/`@CircuitBreaker` em
  `ClienteTaxaCambioExterna`), que sao ativadas automaticamente pela autoconfiguracao do
  `resilience4j-spring-boot2` + `spring-boot-starter-aop`, sem qualquer necessidade de
  `@EnableRetry`. A anotacao (e o `@EnableAsync`, tambem sem uso real no codigo) foram removidos.
- **`@Version` com tipo `int` vs `Long`:** a sugestao inicial usava `int` para o campo de
  optimistic locking: funcional, mas com risco maior de overflow silencioso em tabelas com muitas
  atualizacoes ao longo do tempo. Trocado para `Long`.
- **Calculo de `(1 + taxa) ^ prazo` com prazo fracionario:** a sugestao inicial usava
  `BigDecimal.pow(int)`, que so aceita expoente inteiro. Como o prazo em meses e calculado como
  fracao (dias / 30), foi necessario reescrever usando `Math.exp(prazo * ln(base))` para suportar
  expoente fracionario com precisao controlada via `MathContext`.
- **Especificacao dinamica (`Specification<Transacao>`) apagando filtros silenciosamente:** a
  primeira versao gerada ignorava o filtro de moeda quando o valor vinha vazio (string vazia
  tratada como "match tudo" de forma inconsistente com os demais filtros). Foi padronizado o uso
  de `StringUtils.hasText(...)` em todos os filtros para consistencia.
- **Sugestao de usar Husky para git hooks:** por ser um projeto 100% Java/Maven sem Node.js no
  build, foi decidido nao adicionar uma dependencia de tooling Node apenas para hooks. Optou-se
  por hooks shell simples em `.githooks/` (`git config core.hooksPath .githooks`), documentado no
  README, mantendo o toolchain homogeneo.
- **`@RequestParam LocalDate` sem `@DateTimeFormat` (bug real, reportado apos deploy):** os
  endpoints de filtro por data (`ControladorTransacao.buscar`, `ControladorRelatorio.extrato`,
  `ControladorGradeTransacoes.grade`) foram gerados apenas com `@RequestParam LocalDate`, sem
  `@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)`. Isso funcionava em alguns ambientes por
  conversao implicita, mas falhou em producao com
  `MethodArgumentTypeMismatchException: Failed to convert ... to type LocalDate` para valores
  como `2026-08-24`. A IA nao havia testado esse caminho fim a fim (nao ha como rodar o servidor
  neste ambiente de sandbox); a correcao foi adicionar `@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)`
  em todos os `@RequestParam LocalDate` da aplicacao. Licao: parametros de data/hora via query
  string no Spring MVC precisam de formato explicito - nao dependa da conversao implicita.
- **Traducao integral do codigo para portugues (classes, metodos, variaveis, constantes,
  comentarios):** a IA renomeou sistematicamente todos os identificadores Java do projeto. O
  maior risco tecnico aqui nao foi de vocabulario, e sim de *acoplamento*: os nomes de metodo do
  Spring Data (`findByCodigo`, `findFirstByMoedaOrderByVigenteEmDesc`, etc.) sao *derivados por
  reflexao* a partir dos nomes de campo das entidades - renomear um campo sem renomear o metodo
  de consulta correspondente quebraria a aplicacao em runtime (`PropertyReferenceException`), nao
  em tempo de compilacao. O mesmo vale para os nomes usados em `Sort.by(...)` e nas chaves JSON
  trocadas com o `operator.js`/`transactions.js` (que precisam bater com os nomes de campo dos
  DTOs serializados pelo Jackson). A IA tratou essas tres camadas (nome de campo Java, metodo de
  consulta derivado, chave JSON) como uma unidade a ser renomeada em conjunto, em vez de fazer uma
  troca de texto ingenua. Foi deliberadamente decidido **nao** traduzir: (a) nomes de metodos que
  sao overrides obrigatorios de interfaces do Spring/Hibernate (ex: `doFilterInternal`, `run`,
  `hasAlterTable`), pois isso quebraria o contrato de sobrescrita; e (b) os nomes fisicos de
  colunas/tabelas no banco (`@Column(name=...)`, DDL, SQL nativo), por serem strings de schema,
  nao identificadores de codigo Java.

## Analise critica

**Onde a IA economizou tempo:**
- Boilerplate repetitivo (getters/setters via Lombok, DTOs, `@RestControllerAdvice` com todos os
  handlers de excecao, configuracao inicial do `application.yml` com Resilience4j/Actuator).
- Geracao dos diagramas Mermaid (C4 e ER) e da primeira versao do DDL documental, que seriam
  trabalhosos de escrever a mao em formato consistente.
- Estrutura inicial dos testes unitarios (JUnit5 + Mockito + AssertJ), permitindo focar o tempo
  humano em validar os *cenarios* de teste (concorrencia, spread condicional) em vez da
  sintaxe do framework.

**Onde a IA atrapalhou / exigiu supervisao extra:**
- Qualquer decisao envolvendo **precisao numerica financeira** (escala de `BigDecimal`,
  arredondamento, exponenciacao fracionaria) precisou de revisao manual cuidadosa - a IA tende a
  sugerir o caminho "mais simples" (`double`, `pow(int)`) que e inadequado para calculo financeiro.
- Sugestoes de dependências desatualizadas (dialect do SQLite) exigiram verificacao manual de
  compatibilidade com as versoes reais do Spring Boot/Hibernate escolhidas.
- A IA nao tem conhecimento de contexto de negocio implicito (ex: por que um cheque pre-datado de
  prazo longo deveria ter risco adicional); essas regras de negocio foram definidas e validadas
  por mim, com a IA apenas implementando a estrutura de codigo (Strategy) para expressa-las de
  forma desacoplada.
- O ambiente onde a IA trabalhou nao tem acesso ao Maven Central nem consegue subir a aplicacao
  Spring Boot de fato, entao erros que so aparecem em tempo de execucao (o dialect do Hibernate,
  o `@DateTimeFormat` ausente) so foram pegos depois que eu rodei o projeto de verdade e colei o
  stack trace de volta. Isso reforca que revisao de codigo gerado por IA nao substitui rodar o
  codigo.

**Conclusao:** a IA foi usada para acelerar estrutura, boilerplate e documentacao, nunca para
substituir o entendimento do problema de negocio (precisao decimal, ACID, regras de risco), que
permanece de minha responsabilidade e autoria.
