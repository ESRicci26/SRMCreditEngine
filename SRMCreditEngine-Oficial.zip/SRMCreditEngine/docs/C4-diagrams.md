# Diagramas C4 - SRM Credit Engine

## Nivel 1 - Diagrama de Contexto

```mermaid
C4Context
title Contexto do Sistema - SRM Credit Engine

Person(operador, "Operador de Mesa", "Precifica e registra a aquisicao de recebiveis")
Person(gestor, "Gestor/Auditoria", "Consulta extratos de liquidacao para auditoria e compliance")

System(srm, "SRM Credit Engine", "Precifica e liquida recebiveis multimoedas com seguranca ACID e auditabilidade")

System_Ext(fxProvider, "Provedor Externo de Cambio", "Fonte de cotacoes de mercado (mock com retry/circuit breaker)")
System_Ext(browser, "Navegador do Operador", "Acessa o Painel do Operador e o Grid de Transacoes via Thymeleaf")

Rel(operador, browser, "Usa")
Rel(browser, srm, "HTTP/HTTPS")
Rel(gestor, srm, "Consulta via API/Swagger")
Rel(srm, fxProvider, "Busca cotacoes de cambio (resiliente)")
```

## Nivel 2 - Diagrama de Container

```mermaid
C4Container
title Container - SRM Credit Engine

Person(operador, "Operador de Mesa")

Container_Boundary(srm, "SRM Credit Engine") {
    Container(web, "Web UI (Thymeleaf)", "HTML/Bootstrap/JS", "Painel do Operador e Grid de Transacoes, server-side rendered")
    Container(api, "REST API", "Spring Boot / Java 11", "Currency Engine, Pricing Engine (Strategy), Transacoes, Relatorios")
    Container(service, "Camada de Servico", "Spring Service", "Regras de negocio, orquestracao transacional (ACID), optimistic locking")
    Container(repo, "Camada de Persistencia", "Spring Data JPA + JDBC nativo", "Repositorios JPA para o dominio; JDBC nativo para relatorios analiticos")
    ContainerDb(db, "SQLite", "Arquivo local (raiz do projeto)", "Moedas, taxas, tipos de recebivel, transacoes")
}

System_Ext(fxProvider, "Provedor Externo de Cambio")

Rel(operador, web, "Usa", "HTTPS")
Rel(web, api, "Chama", "fetch/JSON")
Rel(api, service, "Delega")
Rel(service, repo, "Usa")
Rel(repo, db, "JDBC")
Rel(service, fxProvider, "Retry + Circuit Breaker (Resilience4j)")
```

## Notas de Arquitetura

- **3 camadas no backend de dominio:** `controller -> service -> repository`, com DTOs
  isolando a API dos agregados JPA.
- **2 camadas nos relatorios:** `ControladorRelatorio -> RepositorioRelatorioExtrato` (SQL nativo via
  `NamedParameterJdbcTemplate`), propositalmente sem passar pela camada de servico, para
  otimizar consultas analiticas de grande volume.
- **ACID:** toda escrita financeira ocorre dentro de um unico `@Transactional`
  (`ServicoTransacao`), e a liquidacao usa **optimistic locking** (`@Version`) para evitar
  condicoes de corrida em liquidacoes concorrentes.
- **Resiliencia:** chamadas ao provedor externo de cambio usam `@Retry` +
  `@CircuitBreaker` (Resilience4j), com fallback para a ultima taxa persistida localmente.
