# Diagrama ER - SRM Credit Engine

```mermaid
erDiagram
    CURRENCY ||--o{ EXCHANGE_RATE : "base_currency"
    CURRENCY ||--o{ EXCHANGE_RATE : "target_currency"
    CURRENCY ||--o{ BASE_RATE : "currency"
    CURRENCY ||--o{ TRANSACTION_LEDGER : "face_currency"
    CURRENCY ||--o{ TRANSACTION_LEDGER : "settlement_currency"
    RECEIVABLE_TYPE ||--o{ TRANSACTION_LEDGER : "receivable_type"

    CURRENCY {
        BIGINT id PK
        VARCHAR code "BRL, USD (unique)"
        VARCHAR name
        VARCHAR symbol
    }

    EXCHANGE_RATE {
        BIGINT id PK
        BIGINT base_currency_id FK
        BIGINT target_currency_id FK
        DECIMAL rate "19,8"
        DATETIME effective_at
    }

    BASE_RATE {
        BIGINT id PK
        BIGINT currency_id FK
        DECIMAL monthly_rate "9,6"
        DATETIME effective_at
    }

    RECEIVABLE_TYPE {
        BIGINT id PK
        VARCHAR code "DUPLICATA_MERCANTIL, CHEQUE_PRE_DATADO (unique)"
        VARCHAR description
        DECIMAL monthly_spread "9,6"
    }

    TRANSACTION_LEDGER {
        BIGINT id PK
        VARCHAR assignor "cedente"
        BIGINT receivable_type_id FK
        DECIMAL face_value "19,4"
        BIGINT face_currency_id FK
        DATE due_date
        DECIMAL term_months "9,4"
        DECIMAL base_rate_applied "9,6"
        DECIMAL spread_applied "9,6"
        DECIMAL present_value "19,4"
        BIGINT settlement_currency_id FK
        DECIMAL exchange_rate_applied "19,8, nullable"
        DECIMAL settled_value "19,4"
        VARCHAR status "PENDING, SETTLED, CANCELED"
        DATETIME created_at
        DATETIME updated_at
        BIGINT version "optimistic locking"
    }
```

## Justificativas de Modelagem

- **Precisao decimal:** todos os valores monetarios usam `DECIMAL` com escala fixa
  (4 casas para valores, 6-8 casas para taxas), nunca `FLOAT`/`DOUBLE`, evitando erros de
  arredondamento em operacoes financeiras.
- **Historico de taxas:** `EXCHANGE_RATE` e `BASE_RATE` sao *append-only* (nunca fazem
  update in-place); cada nova cotacao gera uma nova linha com `effective_at`, preservando
  auditabilidade de qual taxa foi usada em cada operacao no passado.
- **Rastreabilidade da precificacao:** `TRANSACTION_LEDGER` guarda nao so o resultado
  (`present_value`, `settled_value`) mas tambem os insumos usados no calculo
  (`base_rate_applied`, `spread_applied`, `exchange_rate_applied`, `term_months`), permitindo
  reconstruir e auditar qualquer calculo historico mesmo que as taxas de referencia mudem depois.
- **`version` (optimistic locking):** protege a liquidacao contra condicoes de corrida
  quando duas requisicoes tentam liquidar a mesma transacao simultaneamente.
