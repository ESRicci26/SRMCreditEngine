-- ============================================================================
-- SRM Credit Engine - DDL (SQLite)
-- Este script documenta a estrutura gerada automaticamente pelo Hibernate
-- (spring.jpa.hibernate.ddl-auto=update) na primeira subida da aplicacao.
-- Pode tambem ser executado manualmente para inspecionar/recriar o schema.
-- ============================================================================

CREATE TABLE IF NOT EXISTS currency (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    code   VARCHAR(10) NOT NULL UNIQUE,
    name   VARCHAR(60) NOT NULL,
    symbol VARCHAR(5)  NOT NULL
);

CREATE TABLE IF NOT EXISTS receivable_type (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    code           VARCHAR(40) NOT NULL UNIQUE,
    description    VARCHAR(80) NOT NULL,
    monthly_spread DECIMAL(9,6) NOT NULL
);

CREATE TABLE IF NOT EXISTS base_rate (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    currency_id  INTEGER NOT NULL REFERENCES currency(id),
    monthly_rate DECIMAL(9,6) NOT NULL,
    effective_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS exchange_rate (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    base_currency_id   INTEGER NOT NULL REFERENCES currency(id),
    target_currency_id INTEGER NOT NULL REFERENCES currency(id),
    rate               DECIMAL(19,8) NOT NULL,
    effective_at       DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS transaction_ledger (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    assignor                VARCHAR(120) NOT NULL,
    receivable_type_id      INTEGER NOT NULL REFERENCES receivable_type(id),
    face_value              DECIMAL(19,4) NOT NULL,
    face_currency_id        INTEGER NOT NULL REFERENCES currency(id),
    due_date                DATE NOT NULL,
    term_months             DECIMAL(9,4) NOT NULL,
    base_rate_applied       DECIMAL(9,6) NOT NULL,
    spread_applied          DECIMAL(9,6) NOT NULL,
    present_value           DECIMAL(19,4) NOT NULL,
    settlement_currency_id  INTEGER NOT NULL REFERENCES currency(id),
    exchange_rate_applied   DECIMAL(19,8),
    settled_value           DECIMAL(19,4) NOT NULL,
    status                  VARCHAR(20) NOT NULL,
    created_at              DATETIME NOT NULL,
    updated_at              DATETIME NOT NULL,
    version                 INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_transaction_due_date ON transaction_ledger (due_date);
CREATE INDEX IF NOT EXISTS idx_transaction_assignor ON transaction_ledger (assignor);
CREATE INDEX IF NOT EXISTS idx_transaction_status ON transaction_ledger (status);

-- ============================================================================
-- Seed inicial (executado automaticamente por SemeadorDados.java na primeira
-- inicializacao; reproduzido aqui apenas como referencia documental)
-- ============================================================================

-- INSERT INTO currency (code, name, symbol) VALUES ('BRL', 'Real Brasileiro', 'R$');
-- INSERT INTO currency (code, name, symbol) VALUES ('USD', 'Dolar Americano', 'US$');

-- INSERT INTO receivable_type (code, description, monthly_spread)
--   VALUES ('DUPLICATA_MERCANTIL', 'Duplicata Mercantil', 0.0150);
-- INSERT INTO receivable_type (code, description, monthly_spread)
--   VALUES ('CHEQUE_PRE_DATADO', 'Cheque Pre-datado', 0.0250);
